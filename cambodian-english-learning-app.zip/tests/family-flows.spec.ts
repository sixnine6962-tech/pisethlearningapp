import { expect, test } from "@playwright/test";

test("bedtime locks the lesson and the next local day restores the allowance", async ({
  page,
}) => {
  await page.clock.install({ time: new Date("2026-07-08T20:29:35+07:00") });
  await page.goto("/");
  await page.locator(".parent-entry").click();
  await page.locator("#parent-pin").fill("0000");
  await page.getByRole("button", { name: "Unlock · បើកសោ" }).click();
  await page.getByRole("switch", { name: "Enable bedtime lock" }).click();
  await page.locator("input[type=time]").fill("20:30");
  await page.getByRole("button", { name: "Save settings · រក្សាទុក" }).click();
  await page
    .getByRole("button", { name: "Start learning", exact: true })
    .click();
  await page.clock.fastForward(30000);
  await expect(
    page.getByRole("heading", { name: "Sleepy time, little explorer!" }),
  ).toBeVisible();
  await page.clock.fastForward(4 * 60 * 60 * 1000);
  await expect(
    page.getByRole("heading", { name: "Hello, little explorer!" }),
  ).toBeVisible();
  await expect(page.locator(".topbar .time-pill")).toContainText("15:00");
  await expect(page.locator(".word-card h3")).toHaveText("Cat");
});

test("a guardian-approved early exit preserves the unfinished lesson", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Start learning", exact: true })
    .click();
  await page.getByRole("button", { name: "Got it យល់ហើយ" }).click();
  await expect(
    page.getByRole("heading", { name: "Meet the letter B" }),
  ).toBeVisible();
  await page.getByLabel("End study session with parent PIN").click();
  await page.locator("#parent-pin").fill("0000");
  await page.getByRole("button", { name: "Unlock · បើកសោ" }).click();
  await page.reload();
  await page
    .getByRole("button", { name: "Continue learning", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Meet the letter B" }),
  ).toBeVisible();
});

test("shop purchases persist and a bilingual conversation rewards the learner", async ({
  page,
}) => {
  await page.goto("/#profile");
  await page.getByRole("button", { name: "Visit the shop" }).click();
  await page
    .locator(".shop-row")
    .filter({ hasText: "Pip the panda" })
    .getByRole("button")
    .click();
  await expect(page.locator(".shop-balance")).toContainText("20 gems");
  await expect(
    page
      .locator(".shop-row")
      .filter({ hasText: "Finn the fox" })
      .getByRole("button"),
  ).toBeDisabled();
  await page.getByLabel("Close dialog").click();
  await page.reload();
  await expect(page.locator(".profile-intro .avatar")).toContainText("🐼");
  await page.locator(".side-nav button").nth(1).click();
  await page.locator(".conversation-card").first().click();
  await page.getByRole("button", { name: /Next line/ }).click();
  await page.getByRole("button", { name: /Next line/ }).click();
  await page.locator(".answer-pick").filter({ hasText: "Mina" }).click();
  await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  await expect(page.locator(".story-ending")).toContainText(
    "Nice to meet you too!",
  );
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  await expect(
    page.getByRole("heading", { name: "Practice complete!" }),
  ).toBeVisible();
  await expect(page.locator(".complete-stats").first()).toContainText("10");
});
