import { expect, test, type Page } from "@playwright/test";
import { exerciseCount, units } from "../src/lib/lessonsData";
const store = "pisethlearning.learner.v1";
async function parentPin(page: Page, pin = "0000") {
  await page.locator("#parent-pin").fill(pin);
  await page
    .getByRole("button", { name: "Unlock · បើកសោ", exact: true })
    .click();
}
async function endSession(page: Page, pin = "0000") {
  await page
    .getByRole("button", {
      name: "End study session with parent PIN",
      exact: true,
    })
    .click();
  await parentPin(page, pin);
}
test("curriculum covers all seven formats, all letters and five full units", () => {
  expect(units).toHaveLength(5);
  expect(exerciseCount).toBe(276);
  for (const unit of units) {
    const q = unit.lessons.flatMap((l) => l.questions);
    expect(q.length).toBeGreaterThanOrEqual(15);
    expect(new Set(q.map((x) => x.type)).size).toBe(7);
    expect(q.every((x) => x.prompt.en && x.prompt.km)).toBeTruthy();
  }
  expect(
    units[0].lessons
      .flatMap((l) => l.questions)
      .filter((q) => q.type === "flashcard")
      .map((q) => (q.type === "flashcard" ? q.word.letter : ""))
      .join(""),
  ).toBe("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
});
test("desktop classroom, all destinations and mobile navigation", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Hello, little explorer!" }),
  ).toBeVisible();
  await expect(page.locator(".unit-card")).toHaveCount(5);
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: ".qa/desktop.png", fullPage: true });
  await page
    .getByRole("button", { name: "View Unit 2: Greetings & Polite Words" })
    .click();
  await expect(
    page.getByText("Finish Unit 1 to unlock this adventure."),
  ).toBeVisible();
  await page.getByLabel("Close dialog").click();
  for (const [index, title] of [
    [1, "Speak & Chat"],
    [2, "Friendly leaderboard"],
    [3, "Your daily quests"],
    [4, "Learner profile"],
  ] as const) {
    await page.locator(".side-nav button").nth(index).click();
    await expect(
      page.getByRole("heading", { name: title, exact: true }),
    ).toBeVisible();
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.locator(".bottom-nav button").first().click();
  await expect(
    page.getByRole("heading", { name: "Your learning path" }),
  ).toBeVisible();
  await expect(page.locator(".bottom-nav")).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBeTruthy();
  await page.screenshot({ path: ".qa/mobile.png", fullPage: true });
  expect(errors).toEqual([]);
});
test("guardian sets five minutes; expiry, reload and extension are protected", async ({
  page,
}) => {
  await page.clock.install();
  await page.goto("/");
  await page.locator(".parent-entry").click();
  await parentPin(page, "1111");
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(
    "does not match",
  );
  await parentPin(page);
  await page.getByRole("button", { name: "5 min", exact: true }).click();
  await page.getByRole("button", { name: "Save settings · រក្សាទុក" }).click();
  await expect(page.locator(".topbar .time-pill")).toContainText("05:00");
  await page
    .getByRole("button", { name: "Start learning", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Meet the letter A" }),
  ).toBeVisible();
  await page.clock.fastForward(60000);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Meet the letter A" }),
  ).toBeVisible();
  await page.getByLabel("End study session with parent PIN").click();
  await expect(page.locator("#parent-pin")).toBeVisible();
  await page.getByLabel("Close dialog").click();
  await page.clock.fastForward(240500);
  await expect(page.getByRole("heading", { name: "Time’s up!" })).toBeVisible();
  await page.reload();
  await expect(page.getByRole("heading", { name: "Time’s up!" })).toBeVisible();
  await page.locator(".rest-card .secondary").click();
  await parentPin(page);
  await page
    .getByRole("button", { name: "Allow 5 more minutes today" })
    .click();
  await expect(
    page.getByRole("heading", { name: "Hello, little explorer!" }),
  ).toBeVisible();
  await expect(page.locator(".topbar .time-pill")).toContainText("05:00");
});
test("all seven exercises complete a lesson and award a claimable daily reward", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Start learning", exact: true })
    .click();
  for (let i = 0; i < 5; i++)
    await page.getByRole("button", { name: /Got it យល់ហើយ/ }).click();
  await page.locator(".answer-pick").filter({ hasText: "Apple" }).click();
  await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  await page.locator(".answer-pick").filter({ hasText: "Cat" }).click();
  await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  for (const [en, km] of [
    ["Apple", "ផ្លែប៉ោម"],
    ["Ball", "បាល់"],
    ["Cat", "ឆ្មា"],
    ["Dog", "ឆ្កែ"],
    ["Egg", "ស៊ុត"],
  ]) {
    await page
      .locator(".pair-columns>div")
      .first()
      .getByRole("button", { name: en, exact: true })
      .click();
    await page
      .locator(".pair-columns>div")
      .last()
      .getByRole("button", { name: km, exact: true })
      .click();
  }
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  for (const w of ["I", "see", "a", "cat"])
    await page
      .locator(".word-bank")
      .getByRole("button", { name: w, exact: true })
      .click();
  await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  await page
    .getByRole("button", { name: /Practice without a microphone/ })
    .click();
  await page.getByRole("button", { name: /I practiced/ }).click();
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  await page.getByRole("button", { name: /Next line/ }).click();
  await page.locator(".answer-pick").filter({ hasText: "Ball" }).click();
  await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  await page.getByRole("button", { name: "Continue បន្ត" }).click();
  await expect(
    page.getByRole("heading", { name: "Lesson complete!" }),
  ).toBeVisible();
  await endSession(page);
  await page.getByRole("button", { name: /Claim \+10/ }).click();
  const saved = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!),
    store,
  );
  expect(saved.xp).toBe(20);
  expect(saved.gems).toBe(65);
  expect(saved.daily.claimed).toBe(true);
  expect(saved.completed).toEqual(["u1-l1"]);
});
test("create account with email and password, sign in, update password and sync progress", async ({
  page,
}) => {
  const email = `family-${Date.now()}@outlook.test`;
  const original = "FamilyPassword!2468";
  const replacement = "NewFamilyPassword!9527";
  await page.goto("/#profile");
  await page.getByRole("button", { name: "Sign in / Create account" }).click();
  await page.getByRole("button", { name: /Create an account/ }).click();
  await expect(
    page.getByRole("heading", { name: "Who is learning?" }),
  ).toBeVisible();
  await page.getByPlaceholder("e.g. Dara").fill("Dara");
  await page.getByRole("button", { name: "Continue · បន្ត" }).click();
  await page.locator(".pin-input").fill("4826");
  await page.getByRole("button", { name: "5 min", exact: true }).click();
  await page.getByRole("button", { name: "Continue · បន្ត" }).click();
  await page.getByPlaceholder("parent@example.com").fill(email);
  await page.getByPlaceholder("At least 8 characters").fill(original);
  await page.getByPlaceholder("Type the password again").fill(original);
  await expect(
    page.getByText(/No verification code or email is required/i),
  ).toBeVisible();
  await expect(page.getByPlaceholder("Verification code")).toHaveCount(0);
  await page
    .getByRole("button", { name: "Create account · បង្កើតគណនី" })
    .click();
  await expect(
    page.getByRole("heading", { name: /A friendly daily reminder\?/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: /Not now/ }).click();
  await expect(
    page.getByRole("heading", { name: "Dara", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("Progress backed up")).toBeVisible();
  let server = await page.request.get("/api/progress");
  expect(server.ok()).toBeTruthy();
  expect((await server.json()).progress.name).toBe("Dara");

  await page
    .locator(".account-actions")
    .getByRole("button", { name: "Sign out" })
    .click();
  await parentPin(page, "4826");
  await page.getByRole("button", { name: "Sign in / Create account" }).click();
  await parentPin(page, "4826");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Sign in · ចូលប្រើគណនី" })
    .click();
  await page.getByPlaceholder("parent@example.com").fill(email);
  await page.getByPlaceholder("Your password").fill("WrongPassword!2468");
  await page
    .getByRole("button", { name: /Sign in/ })
    .last()
    .click();
  await expect(page.locator(".auth-flow .form-error")).toContainText(
    "Email or password is incorrect",
  );
  await page.getByPlaceholder("Your password").fill(original);
  await page
    .getByRole("button", { name: /Sign in/ })
    .last()
    .click();
  await expect(
    page.getByRole("heading", { name: "Dara", exact: true }),
  ).toBeVisible();

  await page.getByRole("button", { name: "Change password" }).click();
  await parentPin(page, "4826");
  await page.getByLabel("Current password").fill("NotTheCurrentPassword!99");
  await page.getByLabel(/New password/).fill(replacement);
  await page
    .getByRole("button", { name: /Change password/ })
    .last()
    .click();
  await expect(page.locator(".modal .form-error")).toContainText(
    "current password is incorrect",
  );
  await page.getByLabel("Current password").fill(original);
  await page
    .getByRole("button", { name: /Change password/ })
    .last()
    .click();
  await expect(page.getByText("Your password has been changed.")).toBeVisible();
  server = await page.request.get("/api/progress");
  expect(server.ok()).toBeTruthy();
  expect((await server.json()).progress.email).toBe(email);
  await page
    .locator(".account-actions")
    .getByRole("button", { name: "Sign out" })
    .click();
  await parentPin(page, "4826");
  await page.getByRole("button", { name: "Sign in / Create account" }).click();
  await parentPin(page, "4826");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Sign in · ចូលប្រើគណនី" })
    .click();
  await page.getByPlaceholder("parent@example.com").fill(email);
  await page.getByPlaceholder("Your password").fill(original);
  await page
    .getByRole("button", { name: /Sign in/ })
    .last()
    .click();
  await expect(page.locator(".auth-flow .form-error")).toContainText(
    "Email or password is incorrect",
  );
  await page.getByPlaceholder("Your password").fill(replacement);
  await page
    .getByRole("button", { name: /Sign in/ })
    .last()
    .click();
  await expect(
    page.getByRole("heading", { name: "Dara", exact: true }),
  ).toBeVisible();
});
