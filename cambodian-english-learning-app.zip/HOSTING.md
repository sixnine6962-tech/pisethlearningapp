# Hosting PisethLearning

## Why there is no `index.html`

PisethLearning is a **full-stack Next.js website**, not a collection of standalone HTML files. Its homepage is `src/app/page.tsx`; Next.js generates and serves the page while the application is running. A static `index.html` is neither required nor useful for its PostgreSQL-backed authentication and learning progress.

## Recommended hosting

Deploy this project as a Next.js application on **Vercel** or another host that runs Node.js. It will not work as-is when uploaded to a static-only host or a simple `public_html` folder.

1. Create a hosted PostgreSQL database (for example, Neon or Supabase Database).
2. Commit the project to a private GitHub repository. Use GitHub Desktop if preferred. **Do not commit `.env` or reveal the database password.**
3. Import the repository as a Next.js project in Vercel.
4. Add `DATABASE_URL` in the host’s environment-variable settings. Use the **hosted** PostgreSQL connection string—not the development computer’s local database URL.
5. Apply the tables once using the production database connection. Windows PowerShell, from the project directory:

   ```powershell
   $env:DATABASE_URL = "YOUR_HOSTED_POSTGRES_CONNECTION_STRING"
   npx drizzle-kit push
   ```

6. Optionally add a long random `AUTH_RATE_LIMIT_SECRET` to your hosting environment for pseudonymous sign-in-rate-limit keys. If omitted, the private database connection string is used to derive them.
7. Deploy. The host builds and runs Next.js automatically. Check `https://your-domain/api/health`; a healthy database returns `{"ok":true}`.
8. Attach a custom domain if desired.

**Email/password accounts do not need Supabase Auth, SMTP, an email sender, email verification, or OTP settings.** Families register and sign in immediately with Gmail, Outlook, or another email address and their chosen password. Those addresses are used as account usernames; no email is sent.

## Other Node.js hosting

A managed Node provider or VPS also works. Use Node.js 20.9 or later, configure `DATABASE_URL`, push the schema, and run the production server behind HTTPS:

```bash
npm ci
npm run build
npm run start
```

Keep the server running with your provider’s process manager. The application normally listens on port 3000.

## Static-only hosting

This full-stack application is deliberately **not** configured for static export. Adding a standalone `index.html` or setting `output: "export"` will not provide a working database, sessions, account creation, or progress API. The managed preview is useful for testing; deploy your own Node.js/Next.js project for a permanent public address.
