# GitHub Pages Troubleshooting for PisethLearning

## Why you see 404 on GitHub Pages

Your repository contains a **Next.js full-stack application**, not standalone HTML files.
- There is **no `index.html`** in the repository root.
- GitHub Pages only serves **static files** directly from a repository.
- Next.js generates pages at build time and needs a **Node.js server** to run API routes, database connections, and authentication.

Because of this, uploading the repository to GitHub Pages produces:
```
404 — File not found
```

GitHub Pages expects `index.html` at the repository root for the root URL. PisethLearning does not have one because `src/app/page.tsx` is the homepage source file, not a static HTML file.

## Why this project cannot run as-is on GitHub Pages

PisethLearning uses features that GitHub Pages **cannot** provide:
- `src/app/api/auth/route.ts` — family sign-in, login, password change
- `src/app/api/progress/route.ts` — saving learning progress to PostgreSQL
- `src/app/api/health/route.ts` — database health check
- `DATABASE_URL` — requires a hosted PostgreSQL database
- HTTP-only session cookies

GitHub Pages is static-only. It cannot run Node.js server code or connect to PostgreSQL.

## Option A: Deploy with Vercel (Recommended ✅)

Vercel supports Next.js natively and is free for personal projects.

1. Push your project to a **private GitHub repository**.
2. Go to [Vercel](https://vercel.com) → **Add New → Project**.
3. Import your GitHub repository.
4. Vercel detects Next.js automatically. Do **not** add `index.html`.
5. In **Project Settings → Environment Variables**, add:
   - `DATABASE_URL` — your hosted PostgreSQL connection string (Neon, Supabase Database, etc.)
   - Optionally `AUTH_RATE_LIMIT_SECRET` — a long random string for login rate limiting.
6. Deploy. Open `https://your-project.vercel.app/api/health`; it should return `{"ok":true}`.

## Option B: Deploy with Render / Railway / Fly.io

You can also host this project on any Node.js hosting provider:
1. Set `DATABASE_URL` to your hosted PostgreSQL.
2. Run `npm ci`, `npm run build`, `npm run start`.
3. Keep the server running behind HTTPS.

## Option C: GitHub Pages for Static Frontend Only (Limited)

If you **must** use GitHub Pages, you lose the database, sign-in, and progress-saving features:

1. Add to `next.config.js`:
   ```js
   /** @type {import('next').NextConfig} */
   const nextConfig = {
     output: 'export',
   }
   module.exports = nextConfig
   ```
2. Run `npm run build`. This creates an `out/` folder containing static HTML.
3. Push the contents of `out/` to a GitHub Pages branch (`gh-pages`).
4. Enable GitHub Pages in repository settings.

**Warning:** With static export, `/api/auth`, `/api/progress`, parent PIN, session cookies, and database backup **will not work**. This option is only for viewing lessons offline without account features.

## Recommendation

**Use Vercel.** It keeps all PisethLearning features working:
- Create account with email + password
- Sign in and progress sync
- Parent PIN and daily time limits
- PostgreSQL backups
- No `index.html` needed

If you want help configuring Vercel or a PostgreSQL database (Neon/Supabase), let me know.