import PisethApp from "@/components/PisethApp";
export default function HomePage() {
  return <PisethApp />;
}
