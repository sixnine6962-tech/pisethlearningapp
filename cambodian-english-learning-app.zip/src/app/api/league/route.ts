import { db } from "@/db";
import { learners } from "@/db/schema";
import { weekKey } from "@/lib/model";
import { currentLearner, privateJson } from "@/lib/serverAuth";
import { and, desc, eq, gt, like, or } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const [me, rows] = await Promise.all([
      currentLearner(),
      db
        .select({ id: learners.id, xp: learners.weeklyXp })
        .from(learners)
        .where(
          and(
            eq(learners.week, weekKey()),
            gt(learners.weeklyXp, 0),
            or(
              like(learners.subject, "password:%"),
              like(learners.subject, "supabase:%"),
            ),
          ),
        )
        .orderBy(desc(learners.weeklyXp))
        .limit(20),
    ]);
    return privateJson({
      learners: rows
        .filter((r) => r.id !== me?.id)
        .map((r) => ({
          name: "Explorer " + r.id.slice(0, 4).toUpperCase(),
          xp: r.xp,
          icon: "🌱",
        })),
    });
  } catch {
    return privateJson({ learners: [] });
  }
}
