import { db } from "@/db";
import { learners } from "@/db/schema";
import { sanitizeLearner } from "@/lib/model";
import { currentLearner, privateJson, safeOrigin } from "@/lib/serverAuth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const user = await currentLearner();
    return user
      ? privateJson({
          progress: user.progress,
          email: user.email,
          account: user.subject.startsWith("demo:") ? "demo" : "live",
        })
      : privateJson({ authenticated: false }, 401);
  } catch {
    return privateJson({ error: "Backup unavailable." }, 503);
  }
}
export async function PUT(req: Request) {
  if (!safeOrigin(req)) return privateJson({ error: "Invalid origin." }, 403);
  try {
    const user = await currentLearner();
    if (!user) return privateJson({ error: "Please sign in again." }, 401);
    const text = await req.text();
    if (text.length > 40000)
      return privateJson({ error: "Progress is too large." }, 413);
    const data = JSON.parse(text);
    if (data.version !== 1)
      return privateJson({ error: "Invalid progress format." }, 400);
    const progress = sanitizeLearner(data);
    progress.email = user.email;
    progress.account = user.subject.startsWith("demo:") ? "demo" : "live";
    await db
      .update(learners)
      .set({
        progress,
        weeklyXp: progress.weeklyXp,
        week: progress.week,
        updatedAt: new Date(),
      })
      .where(eq(learners.id, user.id));
    return privateJson({ ok: true });
  } catch {
    return privateJson(
      { error: "Could not back up progress. Device progress is unchanged." },
      503,
    );
  }
}
