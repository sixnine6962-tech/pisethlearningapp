"use client";
import { useLearning } from "@/lib/learning";
import { formatTime, streak } from "@/lib/model";
import {
  BookOpen,
  ChevronDown,
  ChevronRight,
  Clock3,
  Heart,
  MessageCircle,
  ShieldCheck,
  Target,
  Trophy,
  UserRound,
} from "lucide-react";
import { Avatar, FlameArt, GemArt, Tiger } from "./Art";
export type Tab = "learn" | "speak" | "league" | "quests" | "profile";
export type Info = "course" | "streak" | "gems" | "hearts" | "time";
const nav = [
  {
    id: "learn" as Tab,
    label: "Learn",
    km: "មេរៀន",
    Icon: BookOpen,
    color: "green",
  },
  {
    id: "speak" as Tab,
    label: "Speak & Chat",
    km: "សន្ទនា",
    Icon: MessageCircle,
    color: "blue",
  },
  {
    id: "league" as Tab,
    label: "Leaderboard",
    km: "តារាងពិន្ទុ",
    Icon: Trophy,
    color: "gold",
  },
  {
    id: "quests" as Tab,
    label: "Quests",
    km: "បេសកកម្ម",
    Icon: Target,
    color: "purple",
  },
  {
    id: "profile" as Tab,
    label: "Profile",
    km: "គណនី",
    Icon: UserRound,
    color: "coral",
  },
];
export function Sidebar({
  tab,
  onTab,
  onParent,
}: {
  tab: Tab;
  onTab: (t: Tab) => void;
  onParent: () => void;
}) {
  return (
    <aside className="sidebar">
      <button
        className="brand"
        onClick={() => onTab("learn")}
        aria-label="PisethLearning home"
      >
        <Tiger size={43} />
        <span>
          <strong>
            Piseth<span>Learning</span>
          </strong>
          <small>ENGLISH FOR KIDS</small>
        </span>
      </button>
      <div className="sidebar-content">
        <div className="nav-label">MY CLASSROOM</div>
        <nav className="side-nav" aria-label="Main navigation">
          {nav.map(({ id, label, km, Icon, color }) => (
            <button
              key={id}
              onClick={() => onTab(id)}
              className={`nav-link ${tab === id ? "selected" : ""}`}
              aria-current={tab === id ? "page" : undefined}
            >
              <span className={`nav-icon ${color}`}>
                <Icon size={23} strokeWidth={2.3} />
              </span>
              <span>
                <b>{label}</b>
                <small className="km" lang="km">
                  {km}
                </small>
              </span>
              {tab === id && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="parent-entry" onClick={onParent}>
            <span className="parent-shield">
              <ShieldCheck size={22} />
            </span>
            <span>
              <b>Parents’ corner</b>
              <small className="km" lang="km">
                សម្រាប់អាណាព្យាបាល
              </small>
            </span>
            <ChevronRight size={14} />
          </button>
          <div className="credit">
            <span className="credit-dot" /> MadeBy: TryPiseth.LLC
          </div>
        </div>
      </div>
    </aside>
  );
}
export function BottomNav({
  tab,
  onTab,
}: {
  tab: Tab;
  onTab: (t: Tab) => void;
}) {
  return (
    <nav className="bottom-nav" aria-label="Mobile navigation">
      {nav.map(({ id, label, km, Icon, color }) => (
        <button
          key={id}
          onClick={() => onTab(id)}
          className={`${tab === id ? "selected" : ""}`}
          aria-current={tab === id ? "page" : undefined}
        >
          <span className={`nav-icon ${color}`}>
            <Icon size={22} />
          </span>
          <b>
            {label === "Speak & Chat"
              ? "Speak"
              : label === "Leaderboard"
                ? "League"
                : label}
          </b>
          <small className="km" lang="km">
            {km}
          </small>
        </button>
      ))}
    </nav>
  );
}
export function EnglishFlag() {
  return (
    <svg
      className="english-flag"
      viewBox="0 0 36 28"
      width="32"
      height="25"
      aria-label="English course flag"
      role="img"
    >
      <defs>
        <clipPath id="flag-round">
          <rect width="36" height="28" rx="6" />
        </clipPath>
      </defs>
      <g clipPath="url(#flag-round)">
        <path fill="#3c5686" d="M0 0h36v28H0z" />
        <path d="m0 0 36 28M36 0 0 28" stroke="#fff" strokeWidth="6" />
        <path d="m0 0 36 28M36 0 0 28" stroke="#d56c73" strokeWidth="2" />
        <path d="M18 0v28M0 14h36" stroke="white" strokeWidth="10" />
        <path d="M18 0v28M0 14h36" stroke="#d66a72" strokeWidth="5.5" />
      </g>
    </svg>
  );
}
export function Topbar({
  onInfo,
  onProfile,
}: {
  onInfo: (s: Info) => void;
  onProfile: () => void;
}) {
  const { data, seconds } = useLearning();
  return (
    <header className="topbar">
      <button className="course-button" onClick={() => onInfo("course")}>
        <EnglishFlag />
        <span>English course</span>
        <ChevronDown size={14} />
      </button>
      <div className="topbar-right">
        <button
          className="stat-chip streak-stat"
          onClick={() => onInfo("streak")}
          aria-label={`${streak(data)} day streak`}
        >
          <FlameArt size={23} />
          <b>{streak(data)}</b>
        </button>
        <button
          className="stat-chip gem-stat"
          onClick={() => onInfo("gems")}
          aria-label={`${data.gems} gems`}
        >
          <GemArt size={24} />
          <b>{data.gems}</b>
        </button>
        <button
          className="stat-chip heart-stat"
          onClick={() => onInfo("hearts")}
          aria-label={`${data.hearts} hearts`}
        >
          <Heart size={23} fill="#f18b91" stroke="#ed7d83" strokeWidth={1.6} />
          <b>{data.hearts}</b>
        </button>
        <button
          className="time-pill"
          onClick={() => onInfo("time")}
          aria-label="View remaining learning time"
        >
          <Clock3 size={15} />
          <span>Time left</span>
          <b>{formatTime(seconds)}</b>
        </button>
        <span className="header-separator" />
        <button
          className="profile-button"
          onClick={onProfile}
          aria-label="Open learner profile"
        >
          <Avatar size={37} name={data.avatar} />
          <ChevronDown size={13} />
        </button>
      </div>
    </header>
  );
}
