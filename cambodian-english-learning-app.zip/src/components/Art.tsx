import type { CSSProperties } from "react";
export function Tiger({
  size = 48,
  sleeping = false,
  className = "",
}: {
  size?: number;
  sleeping?: boolean;
  className?: string;
}) {
  return (
    <svg
      role="img"
      aria-label={sleeping ? "Tigo is resting" : "Tigo the tiger"}
      width={size}
      height={size}
      viewBox="0 0 80 80"
      className={className}
    >
      <g stroke="#a85b22" strokeWidth="2.1" strokeLinejoin="round">
        <path
          d="M10 27C2 16 9 6 18 9c5 1 8 4 10 7M52 16C57 6 69 5 73 15c3 7 0 11-4 15"
          fill="#f2a13e"
        />
        <path
          d="M12 21c-3-6 2-10 7-6l5 5m32-1c5-8 14-7 13 1l-4 6"
          fill="#f3a390"
          stroke="none"
        />
        <path
          d="M9 34C10 9 64 5 71 34l3 12-4 1 3 7-7 1c-3 17-47 22-54 1l-7-3 4-6-5-1z"
          fill="#f8aa43"
        />
      </g>
      <path
        d="m24 16 7 11 1-14m7-1 3 12 5-12m6 3-2 13 9-10M9 32l13 5-15-1m0 7 15 1-14 5m64-18-14 6 15-1m1 6-16 3 14 3"
        fill="#61402d"
      />
      <path
        d="M12 47c2-7 10-6 17-2 5-6 15-7 21-1 11-7 18-2 19 4-2 18-19 23-30 22C23 69 12 61 12 47"
        fill="#fff1ce"
      />
      {sleeping ? (
        <g fill="none" stroke="#503529" strokeWidth="3.6" strokeLinecap="round">
          <path d="M19 39q7 7 14 0m14 0q7 7 14-1" />
        </g>
      ) : (
        <g>
          <ellipse cx="26" cy="38" rx="5.4" ry="6.6" fill="#473223" />
          <ellipse cx="54" cy="38" rx="5.4" ry="6.6" fill="#473223" />
          <g fill="white">
            <circle cx="27.5" cy="35.8" r="2" />
            <circle cx="55.5" cy="35.8" r="2" />
          </g>
        </g>
      )}
      <path d="M34 47q6-5 12 0l-5 5h-2z" fill="#754331" />
      <path d="M27 53q6 5 13 0 6 4 13-1-3 13-13 13-10-1-13-12" fill="#653827" />
      <path d="M33 60q8-5 15 0-7 8-15 0" fill="#ed9d92" />
      <g fill="#b99365">
        <circle cx="25" cy="48" r="1" />
        <circle cx="29" cy="50" r="1" />
        <circle cx="53" cy="49" r="1" />
        <circle cx="57" cy="47" r="1" />
      </g>
    </svg>
  );
}
export function GemArt({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <path d="m7 5 17 0 6 8-14 16L2 13z" fill="#42bce9" />
      <path d="m7 5 3 8-8 0z" fill="#82ddf6" />
      <path d="m7 5 9 0-6 8z" fill="#b0eafd" />
      <path d="m16 5 6 8H10z" fill="#5bcaf3" />
      <path d="m24 5 6 8h-8z" fill="#178fcf" />
      <path d="M2 13h8l6 16z" fill="#3ba7dc" />
      <path d="M22 13h8L16 29z" fill="#1686c5" />
      <path d="m10 13 6 16 6-16z" fill="#4db8ed" />
    </svg>
  );
}
export function FlameArt({ size = 25 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 36" aria-hidden="true">
      <path
        d="M18 1c1 8 7 9 7 17 2-1 3-4 3-5 8 18-6 25-16 21C-2 30 4 17 12 10c-1 7 1 8 3 7 4-3 1-11 3-16"
        fill="#ff934d"
      />
      <path
        d="M17 20c1 4 5 5 4 9-1 6-11 5-11-1 0-4 4-5 4-9 1 3 1 4 3 1"
        fill="#ffcf65"
      />
    </svg>
  );
}
export function AppleArt({ size = 92 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 110 110"
      role="img"
      aria-label="A red apple"
    >
      <ellipse cx="57" cy="98" rx="30" ry="5" fill="#d8c99e" opacity=".42" />
      <path
        d="M54 34q-3-13 6-23"
        stroke="#795236"
        strokeWidth="5"
        strokeLinecap="round"
        fill="none"
      />
      <path d="M55 26Q35 27 30 10q23-2 25 16" fill="#559747" />
      <path d="M37 15l17 10" stroke="#80b560" strokeWidth="2.4" />
      <path
        d="M53 33c-10-8-29-9-35 7-8 19 4 49 21 55 6 2 11-3 16-1 17 8 32-10 37-28 6-22-3-39-19-38-9 0-13 7-20 5"
        fill="#ed625a"
        stroke="#cf514f"
        strokeWidth="1.7"
      />
      <path
        d="M77 34q21 18 3 47-7 10-15 11 19-2 26-27 5-19-6-28z"
        fill="#db514e"
      />
      <path
        d="M34 38q-9 3-10 15"
        stroke="#ffb4a0"
        strokeWidth="7"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="25" cy="61" r="3" fill="#ffb4a0" />
    </svg>
  );
}
const sparkle = (x: number, y: number, s = 1) => (
  <path
    d={`M${x} ${y - 5 * s}q0 ${4 * s} ${5 * s} ${5 * s}q${-4 * s} 0 ${-5 * s} ${5 * s}q0 ${-4 * s} ${-5 * s} ${-5 * s}q${4 * s} 0 ${5 * s} ${-5 * s}`}
    fill="#efbd52"
  />
);
export function UnitArt({ unit, size = 90 }: { unit: number; size?: number }) {
  const art =
    unit === 1 ? (
      <>
        <ellipse cx="51" cy="84" rx="43" ry="6" fill="#b8d3b9" opacity=".55" />
        <g strokeWidth="1.4" strokeLinejoin="round">
          <g transform="rotate(-8 30 63)" stroke="#428d8d">
            <path d="m11 50 24-8 17 9-24 10z" fill="#9bd8c8" />
            <path d="m11 50 17 11v23L11 73z" fill="#64bcb1" />
            <path d="m28 61 24-10v23L28 84z" fill="#459e9d" />
          </g>
          <g transform="rotate(5 68 66)" stroke="#d89c49">
            <path d="m48 52 24-8 18 10-24 9z" fill="#ffdc8b" />
            <path d="m48 52 18 11v24L48 76z" fill="#f8be5e" />
            <path d="m66 63 24-9v23l-24 10z" fill="#edab4c" />
          </g>
          <g transform="rotate(-6 46 35)" stroke="#ca7c63">
            <path d="m28 20 25-7 18 9-25 8z" fill="#ffbf93" />
            <path d="m28 20 18 10v25L28 45z" fill="#e8926b" />
            <path d="m46 30 25-8v25l-25 8z" fill="#f4a37a" />
          </g>
        </g>
        <g
          fontFamily="Nunito Sans Variable, sans-serif"
          fontWeight="950"
          textAnchor="middle"
          fill="#fff8e8"
        >
          <text x="59" y="44" fontSize="24" transform="rotate(-13 59 44)">
            A
          </text>
          <text x="40" y="73" fontSize="22" transform="rotate(-17 40 73)">
            B
          </text>
          <text x="78" y="77" fontSize="22" transform="rotate(-13 78 77)">
            C
          </text>
        </g>
        {sparkle(15, 25, 0.7)}
        {sparkle(85, 36, 0.85)}
      </>
    ) : unit === 2 ? (
      <>
        <ellipse cx="51" cy="84" rx="38" ry="5" fill="#dfcaac" opacity=".5" />
        <g transform="rotate(6 65 58)">
          <path
            d="M43 45q0-7 9-7h28q9 0 10 10v18q0 9-9 9h-2l4 12-17-12H52q-9 0-9-9z"
            fill="#efb45e"
            stroke="#d9944b"
            strokeWidth="1.8"
          />
          <g fill="#fff5da">
            <circle cx="58" cy="57" r="3" />
            <circle cx="67" cy="57" r="3" />
            <circle cx="76" cy="57" r="3" />
          </g>
        </g>
        <g transform="rotate(-9 40 40)">
          <path
            d="M9 30q0-12 12-12h35q12 0 12 12v18q0 12-12 12H36L20 72l2-13Q9 58 9 47z"
            fill="#82b9a7"
            stroke="#5e9988"
            strokeWidth="1.8"
          />
          <text
            x="22"
            y="48"
            fontFamily="Nunito Sans Variable,sans-serif"
            fontSize="29"
            fontWeight="900"
            fill="#fff9e9"
          >
            Hi!
          </text>
        </g>
        {sparkle(81, 23, 0.9)}
        {sparkle(11, 73, 0.65)}
      </>
    ) : unit === 3 ? (
      <>
        <circle cx="78" cy="27" r="9" fill="#d5b4ec" />
        <circle cx="19" cy="75" r="8" fill="#95c4a9" />
        <g transform="translate(7 10) scale(1.05)">
          <Tiger size={77} />
        </g>
        {sparkle(87, 71, 0.75)}
      </>
    ) : unit === 4 ? (
      <>
        <g transform="translate(-3 1)">
          <AppleArt size={86} />
        </g>
        <g transform="rotate(9 72 68)">
          <rect x="62" y="49" width="27" height="33" rx="6" fill="#efbb6c" />
          <text x="70" y="73" fontWeight="900" fontSize="23" fill="white">
            1
          </text>
        </g>
      </>
    ) : (
      <>
        <path
          d="M13 23q-1-6 8-6h48q9 0 9 9v26q0 9-10 9H43L25 75l2-15q-14 1-14-9z"
          fill="#83b3d0"
        />
        <path
          d="M32 32h28M27 43h24"
          stroke="#f8fcff"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <path
          d="M53 60q0-6 7-6h24q6 0 6 6v15q0 7-7 7h-6l3 9-14-10h-7q-6 0-6-7z"
          fill="#eab872"
        />
        {sparkle(86, 26, 0.8)}
      </>
    );
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden="true">
      {art}
    </svg>
  );
}
export const avatarEmoji: Record<string, string> = {
  panda: "🐼",
  fox: "🦊",
  rabbit: "🐰",
};
export function Avatar({
  name = "tiger",
  size = 44,
  style,
}: {
  name?: string;
  size?: number;
  style?: CSSProperties;
}) {
  return (
    <span className="avatar" style={{ width: size, height: size, ...style }}>
      {name === "tiger" ? (
        <Tiger size={size * 0.8} />
      ) : (
        <span style={{ fontSize: size * 0.65 }}>
          {avatarEmoji[name] || "🐯"}
        </span>
      )}
    </span>
  );
}
