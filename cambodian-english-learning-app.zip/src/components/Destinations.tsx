"use client";
import { useLearning } from "@/lib/learning";
import { bi, conversations, exerciseCount, units } from "@/lib/lessonsData";
import { formatTime, streak } from "@/lib/model";
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  CircleCheck,
  Clock3,
  Crown,
  Heart,
  LockKeyhole,
  MessageCircle,
  Mic,
  ShieldCheck,
  ShoppingBag,
  Sprout,
  Star,
  Target,
  Trophy,
  UserRound,
  Zap,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Avatar, FlameArt, GemArt, Tiger } from "./Art";
import { GoalList } from "./Learn";
import { BiText } from "./UI";
export function SpeakPage() {
  const { start, data } = useLearning();
  return (
    <div className="destination">
      <div className="page-kicker">
        <MessageCircle size={15} /> THE CONVERSATION CLUB
      </div>
      <BiText
        as="h1"
        text={bi("Speak & Chat", "ហាត់និយាយ និងសន្ទនា")}
        className="page-title"
      />
      <section className="speak-banner">
        <div>
          <span className="eyebrow">MEET YOUR SPEAKING BUDDY</span>
          <BiText
            as="h2"
            text={bi("Let’s talk with Tigo!", "តោះនិយាយជាមួយទីហ្គោ!")}
          />
          <p>Friendly conversations, one word at a time.</p>
        </div>
        <Tiger size={115} />
      </section>
      <BiText
        as="h2"
        text={bi("Little conversations", "ការសន្ទនាខ្លីៗ")}
        className="sub-heading"
      />
      <div className="conversation-grid">
        {conversations.map((c, i) => (
          <button
            key={c.title.en}
            className="conversation-card"
            onClick={() => start("u2-l1", "chat", i)}
          >
            <span className="conversation-art" style={{ background: c.tint }}>
              {c.icon}
              <i>✦</i>
            </span>
            <span className="card-copy">
              <small className="eyebrow">STORY {i + 1}</small>
              <strong>{c.title.en}</strong>
              <span className="km" lang="km">
                {c.title.km}
              </span>
              <span className="card-foot">
                <Clock3 size={13} /> 2 min <ArrowRight size={16} />
              </span>
            </span>
          </button>
        ))}
      </div>
      <section className="panel practice-box">
        <span className="feature-icon purple">
          <Mic size={29} />
        </span>
        <div>
          <BiText
            as="h3"
            text={bi("Pronunciation playground", "កន្លែងហាត់បញ្ចេញសំឡេង")}
          />
          <p>Listen, repeat, and find your English voice.</p>
        </div>
        <button
          className="primary"
          onClick={() => start("u3-l1", "speak", data.spoken % 3)}
        >
          Practice <ArrowRight size={16} />
        </button>
      </section>
    </div>
  );
}
export function LeaguePage() {
  const { data } = useLearning();
  const [others, setOthers] = useState<
    { name: string; xp: number; icon: string }[]
  >([]);
  useEffect(() => {
    let alive = true;
    fetch("/api/league")
      .then((r) => r.json())
      .then((b) => {
        if (alive && Array.isArray(b.learners)) setOthers(b.learners);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  const friends = [
    { name: "Tigo", icon: "🐯", xp: 80, role: "Learning buddy" },
    { name: "Pip", icon: "🐼", xp: 60, role: "Learning buddy" },
    { name: "Bunny", icon: "🐰", xp: 40, role: "Learning buddy" },
    { name: "Shelly", icon: "🐢", xp: 20, role: "Learning buddy" },
    ...others.map((o) => ({ ...o, role: "Fellow explorer" })),
    { name: data.name, icon: "", xp: data.weeklyXp, role: "You · អ្នក" },
  ].sort((a, b) => b.xp - a.xp);
  return (
    <div className="destination">
      <div className="page-kicker">
        <Trophy size={15} /> GROW TOGETHER
      </div>
      <BiText
        text={bi("Friendly leaderboard", "តារាងពិន្ទុមិត្តភាព")}
        as="h1"
        className="page-title"
      />
      <div className="league-banner">
        <span className="league-emblem">
          <Sprout size={44} />
        </span>
        <div>
          <span className="eyebrow">WEEKLY KIDS’ LEAGUE</span>
          <h2>Little Sprouts League</h2>
          <p className="km" lang="km">
            ក្រុមពន្លកតូចៗ · រៀនជាមួយគ្នា
          </p>
        </div>
        <span className="league-week">This week</span>
      </div>
      <div className="panel rankings">
        <header>
          <h3>Weekly explorers</h3>
          <span>LEARNING XP</span>
        </header>
        {friends.map((p, i) => (
          <div
            key={p.name + p.role}
            className={`rank-row ${!p.icon ? "is-me" : ""}`}
          >
            <b className={`rank-n n${i}`}>
              {i === 0 ? <Crown size={22} /> : i + 1}
            </b>
            {p.icon ? (
              <span className={`rank-avatar shade-${i % 4}`}>{p.icon}</span>
            ) : (
              <Avatar name={data.avatar} />
            )}
            <span className="rank-name">
              <strong>{p.name}</strong>
              <small>{p.role}</small>
            </span>
            <b className="rank-xp">
              {p.xp} <span>XP</span>
            </b>
          </div>
        ))}
      </div>
      <div className="soft-notice">
        <Heart size={18} />
        <BiText
          text={bi(
            "Everyone learns at their own pace.",
            "យើងម្នាក់ៗរៀនតាមល្បឿនរៀងៗខ្លួន។",
          )}
        />
      </div>
      <p className="muted-caption">
        Practice with animal buddies. Signed-in explorers appear with private
        nicknames. Scores reset every Monday.
      </p>
    </div>
  );
}
export function QuestsPage() {
  const { data } = useLearning();
  const badges = [
    {
      name: "First steps",
      km: "ជំហានដំបូង",
      icon: "🐾",
      earned: data.completed.length > 0,
      desc: "Complete your first lesson",
    },
    {
      name: "Chatty cub",
      km: "កូនខ្លាពូកែនិយាយ",
      icon: "🐯",
      earned: data.spoken >= 3,
      desc: "Practice speaking 3 times",
    },
    {
      name: "Bright spark",
      km: "ផ្កាយភ្លឺ",
      icon: "🌟",
      earned: data.xp >= 100,
      desc: "Earn 100 XP",
    },
    {
      name: "Word explorer",
      km: "អ្នករុករកពាក្យ",
      icon: "🦉",
      earned: data.completed.length >= 5,
      desc: "Complete 5 lessons",
    },
  ];
  return (
    <div className="destination">
      <div className="page-kicker">
        <Target size={15} /> SMALL WINS
      </div>
      <BiText
        as="h1"
        text={bi("Your daily quests", "បេសកកម្មប្រចាំថ្ងៃរបស់អ្នក")}
        className="page-title"
      />
      <div className="quest-columns">
        <section className="panel quest-panel">
          <div className="aside-head">
            <div>
              <h2>
                <Target size={22} className="green-ink" />
                Today’s goals
              </h2>
              <p className="km">គោលដៅថ្ងៃនេះ</p>
            </div>
            <span className="tiny-chip">DAILY</span>
          </div>
          <GoalList expanded />
        </section>
        <section className="quest-reward">
          <span className="reward-gift">🎁</span>
          <h3>A little surprise</h3>
          <p className="km" lang="km">
            រង្វាន់តូចមួយ
          </p>
          <BiText
            text={bi(
              "Finish all three goals to collect 10 gems.",
              "បំពេញគោលដៅទាំងបី ដើម្បីទទួលបានត្បូង ១០។",
            )}
          />
          <span className="gem-reward">
            <GemArt /> +10 gems
          </span>
        </section>
      </div>
      <BiText
        text={bi("Your badge collection", "បណ្ដុំមេដាយរបស់អ្នក")}
        as="h2"
        className="sub-heading"
      />
      <div className="badge-grid">
        {badges.map((b) => (
          <div
            className={`badge-card ${b.earned ? "earned" : ""}`}
            key={b.name}
          >
            <span className="badge-art">{b.icon}</span>
            <strong>{b.name}</strong>
            <span className="km">{b.km}</span>
            <small>{b.desc}</small>
            <span className="badge-status">
              {b.earned ? (
                <>
                  <Check size={12} />
                  Earned
                </>
              ) : (
                <>
                  <LockKeyhole size={11} />
                  Not yet earned
                </>
              )}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
export function ProfilePage({
  onParent,
  onAuth,
  onShop,
  onPassword,
  onLogout,
}: {
  onParent: () => void;
  onAuth: () => void;
  onShop: () => void;
  onPassword: () => void;
  onLogout: () => void;
}) {
  const { data, sync, seconds } = useLearning();
  return (
    <div className="destination">
      <div className="page-kicker">
        <UserRound size={15} /> MY LEARNING SPACE
      </div>
      <BiText
        as="h1"
        text={bi("Learner profile", "គណនីអ្នកសិក្សា")}
        className="page-title"
      />
      <div className="profile-intro panel">
        <Avatar name={data.avatar} size={83} />
        <div>
          <span className="eyebrow">LITTLE EXPLORER</span>
          <h2>{data.name}</h2>
          <p>
            {data.account === "guest"
              ? "Guest learner · Learning on this device"
              : data.email}
          </p>
          <span className="save-label">
            <CircleCheck size={13} />
            {sync === "synced"
              ? "Progress backed up"
              : sync === "saving"
                ? "Saving progress…"
                : sync === "sign-in"
                  ? "Device saved · sign in to sync"
                  : "Progress saved on this device"}
          </span>
        </div>
        <span className="level-chip">
          <Star size={14} fill="currentColor" /> Level{" "}
          {Math.floor(data.xp / 100) + 1}
        </span>
      </div>
      <div className="stat-grid">
        <div>
          <Zap className="gold-ink" />
          <b>{data.xp}</b>
          <span>Total XP</span>
        </div>
        <div>
          <FlameArt />
          <b>{streak(data)}</b>
          <span>Day streak</span>
        </div>
        <div>
          <BookOpen className="green-ink" />
          <b>{data.completed.length}/25</b>
          <span>Lessons learned</span>
        </div>
        <div>
          <GemArt />
          <b>{data.gems}</b>
          <span>Gems collected</span>
        </div>
      </div>
      <div className="profile-grid">
        <section className="panel profile-card">
          <div className="feature-icon green">
            <ShieldCheck size={25} />
          </div>
          <BiText as="h3" text={bi("Parents’ corner", "សម្រាប់អាណាព្យាបាល")} />
          <p>Daily limits, bedtime, reminders, and your family PIN.</p>
          <div className="setting-mini">
            <Clock3 size={15} /> {formatTime(seconds)} remaining today
          </div>
          <button className="secondary" onClick={onParent}>
            <LockKeyhole size={15} /> Parental controls{" "}
            <ChevronRight size={15} />
          </button>
        </section>
        <section className="panel profile-card">
          <div className="feature-icon purple">
            <ShoppingBag size={24} />
          </div>
          <BiText as="h3" text={bi("Explorer shop", "ហាងអ្នករុករក")} />
          <p>Spend your learning gems on a new animal buddy.</p>
          <div className="setting-mini">
            <GemArt size={17} /> {data.gems} gems available
          </div>
          <button className="secondary" onClick={onShop}>
            Visit the shop <ChevronRight size={15} />
          </button>
        </section>
      </div>
      <section className="panel account-row">
        <span className="feature-icon blue">
          <UserRound size={25} />
        </span>
        <div>
          <h3>
            {data.account === "guest"
              ? "Save your learning adventure"
              : "Your family account"}
          </h3>
          <p className="km" lang="km">
            {data.account === "guest"
              ? "បង្កើតគណនី ដើម្បីរក្សាទុកការសិក្សា។"
              : "គណនីរបស់គ្រួសារអ្នក"}
          </p>
        </div>
        {data.account === "guest" || sync === "sign-in" ? (
          <button className="primary" onClick={onAuth}>
            Sign in / Create account <ArrowRight size={15} />
          </button>
        ) : (
          <div className="account-actions">
            <button className="secondary" onClick={onPassword}>
              <LockKeyhole size={14} /> Change password
            </button>
            <button className="secondary" onClick={onLogout}>
              Sign out
            </button>
          </div>
        )}
      </section>
      <p className="profile-credit">
        PisethLearning · {units.length} units · {exerciseCount} activities
        <br />
        MadeBy: TryPiseth.LLC
      </p>
    </div>
  );
}
export function Shop() {
  const { data, update, toast } = useLearning();
  const items = [
    { id: "tiger", name: "Tigo the tiger", price: 0 },
    { id: "panda", name: "Pip the panda", price: 30 },
    { id: "rabbit", name: "Bunny the rabbit", price: 45 },
    { id: "fox", name: "Finn the fox", price: 60 },
  ];
  return (
    <>
      <div className="modal-icon purple">
        <ShoppingBag size={28} />
      </div>
      <BiText
        text={bi("Explorer shop", "ហាងអ្នករុករក")}
        as="h2"
        className="modal-heading"
      />
      <div className="shop-balance">
        <GemArt size={20} />
        {data.gems} gems
      </div>
      <div className="shop-list">
        {items.map((item) => {
          const owned = data.inventory.includes(item.id) || item.id === "tiger";
          const selected = data.avatar === item.id;
          return (
            <div className="shop-row" key={item.id}>
              <Avatar name={item.id} />
              <strong>{item.name}</strong>
              <button
                className={selected ? "selected-item" : "secondary"}
                disabled={selected || (!owned && data.gems < item.price)}
                onClick={() =>
                  update((s) => {
                    if (!owned && s.gems < item.price) return s;
                    return {
                      ...s,
                      avatar: item.id,
                      inventory: owned
                        ? s.inventory
                        : [...s.inventory, item.id],
                      gems: s.gems - (owned ? 0 : item.price),
                    };
                  })
                }
              >
                {selected ? (
                  <>
                    <Check size={13} />
                    In use
                  </>
                ) : owned ? (
                  "Use buddy"
                ) : (
                  <>
                    <GemArt size={15} />
                    {item.price}
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
      <button
        className="secondary full"
        disabled={data.hearts >= 5 || data.gems < 20}
        onClick={() => {
          update((s) =>
            s.gems >= 20 && s.hearts < 5
              ? { ...s, gems: s.gems - 20, hearts: 5 }
              : s,
          );
          toast("Hearts refilled! · បេះដូងពេញវិញហើយ!");
        }}
      >
        <Heart size={16} fill="#ed7d83" color="#ed7d83" />
        {data.hearts === 5
          ? "Your hearts are full"
          : "Refill all hearts · 20 gems"}
      </button>
    </>
  );
}
