"use client";
import { useLearning } from "@/lib/learning";
import { units, wordBanks, type Unit } from "@/lib/lessonsData";
import { nextLesson, unitUnlocked } from "@/lib/model";
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronRight,
  Clock3,
  Gift,
  Layers3,
  LockKeyhole,
  Mic,
  Route,
  Sparkles,
  Star,
  Sun,
  Target,
  Trophy,
  Zap,
} from "lucide-react";
import { AppleArt, GemArt, UnitArt } from "./Art";
import { AudioButton, BiText, ProgressBar } from "./UI";
export function GoalList({ expanded = false }: { expanded?: boolean }) {
  const { data, update, toast } = useLearning();
  const goals = [
    {
      en: "Complete a lesson",
      km: "បញ្ចប់មេរៀនមួយ",
      icon: BookOpen,
      value: data.daily.lessons,
      max: 1,
      color: "green",
    },
    {
      en: "Earn 20 XP",
      km: "ទទួលបាន ២០ ពិន្ទុ",
      icon: Zap,
      value: data.daily.xp,
      max: 20,
      color: "gold",
    },
    {
      en: "Practice speaking",
      km: "ហាត់និយាយភាសាអង់គ្លេស",
      icon: Mic,
      value: data.daily.speaking,
      max: 1,
      color: "purple",
    },
  ];
  const all = goals.every((g) => g.value >= g.max);
  function claim() {
    if (!all || data.daily.claimed) return;
    update((s) =>
      s.daily.claimed
        ? s
        : { ...s, gems: s.gems + 10, daily: { ...s.daily, claimed: true } },
    );
    toast("Daily reward collected! +10 gems · ទទួលបានត្បូង ១០");
  }
  return (
    <div className={`goal-list ${expanded ? "expanded" : ""}`}>
      {goals.map(({ en, km, icon: I, value, max, color }) => (
        <div className="goal-row" key={en}>
          <span className={`goal-icon ${color}`}>
            <I size={expanded ? 25 : 20} strokeWidth={2.25} />
          </span>
          <div className="goal-details">
            <div className="goal-name">
              {en}
              {value >= max && <Check size={13} />}
            </div>
            <p className="km" lang="km">
              {km}
            </p>
            <div className="goal-progress">
              <ProgressBar value={value} max={max} color={`var(--${color})`} />
              <span>
                {Math.min(max, value)}/{max}
              </span>
            </div>
          </div>
        </div>
      ))}
      <div className={`reward-strip ${all ? "ready" : ""}`}>
        <span>
          <Gift size={17} />{" "}
          {data.daily.claimed ? "Reward collected" : "Daily reward"}
        </span>
        {all && !data.daily.claimed ? (
          <button onClick={claim}>
            Claim +10 <GemArt size={16} />
          </button>
        ) : (
          <b>
            <GemArt size={16} /> +10
          </b>
        )}
      </div>
    </div>
  );
}
export function UnitCard({
  unit,
  onClick,
}: {
  unit: Unit;
  onClick: () => void;
}) {
  const { data } = useLearning();
  const amount = unit.lessons.filter((l) =>
    data.completed.includes(l.id),
  ).length;
  const open = unitUnlocked(data, unit.id);
  const current = nextLesson(data).id.startsWith(`u${unit.id}-`);
  return (
    <div className={`path-step ${current ? "current" : ""}`}>
      <span
        className={`path-node ${current ? "active" : amount === 5 ? "done" : ""}`}
      >
        {current ? (
          <Star size={16} fill="currentColor" />
        ) : amount === 5 ? (
          <Check size={15} />
        ) : (
          <LockKeyhole size={13} />
        )}
      </span>
      <button
        className={`unit-card ${current ? "current-card" : ""}`}
        onClick={onClick}
        aria-label={`View Unit ${unit.id}: ${unit.title.en}`}
      >
        <span
          className={`unit-art art-${unit.id}`}
          style={{ backgroundColor: unit.tint }}
        >
          <UnitArt unit={unit.id} />
        </span>
        <span className="unit-main">
          <span className="unit-overline" style={{ color: unit.color }}>
            UNIT {String(unit.id).padStart(2, "0")}
            {current && (
              <span className="current-tag">
                <i />{" "}
                {amount === 0 &&
                !unit.lessons.some((l) => data.bookmarks[l.id] > 0)
                  ? "START HERE"
                  : "IN PROGRESS"}
              </span>
            )}
          </span>
          <span className="unit-title">{unit.title.en}</span>
          <span lang="km" className="km unit-km">
            {unit.title.km}
          </span>
          <span className="unit-metadata">
            {current ? (
              <>
                <span className="lesson-segments">
                  {unit.lessons.map((l) => (
                    <i
                      key={l.id}
                      className={data.completed.includes(l.id) ? "filled" : ""}
                    />
                  ))}
                </span>
                <span>{amount}/5 lessons</span>
              </>
            ) : (
              <>
                <BookOpen size={13} />
                <span>5 lessons</span>
                <i className="meta-dot" />
                <span>
                  {unit.lessons.reduce((n, l) => n + l.questions.length, 0)}{" "}
                  activities
                </span>
              </>
            )}
          </span>
        </span>
        <span className={`unit-go ${current ? "active" : ""}`}>
          {open ? <ChevronRight size={20} /> : <LockKeyhole size={16} />}
        </span>
      </button>
    </div>
  );
}
export function LearnPage({
  onUnit,
  onQuests,
}: {
  onUnit: (n: number) => void;
  onQuests: () => void;
}) {
  const { data, start } = useLearning();
  const featuredWords = [
    wordBanks[0][0],
    wordBanks[2][0],
    wordBanks[0][18],
    wordBanks[4][0],
    wordBanks[0][5],
    wordBanks[0][10],
    wordBanks[2][10],
  ];
  const learningDay =
    Math.max(
      0,
      Math.floor(
        (Date.parse(data.day) - Date.parse(data.joinedDay)) / 86400000,
      ),
    ) || 0;
  const featured = featuredWords[learningDay % featuredWords.length];
  const greeting =
    data.name === "Little Explorer"
      ? "Hello, little explorer!"
      : `Hello, ${data.name}!`;
  return (
    <>
      <section className="adventure-hero">
        <div className="hero-scenery" />
        <div className="hero-content">
          <span className="hero-eyebrow">
            <Sun size={14} fill="#ffda7e" stroke="#bd8a32" /> YOUR DAILY
            ADVENTURE
          </span>
          <div className="hero-greeting">
            <h1>{greeting}</h1>
            <AudioButton text={greeting} small />
          </div>
          <p className="hero-km km" lang="km">
            {data.name === "Little Explorer"
              ? "សួស្តី អ្នករុករកតូច!"
              : `សួស្តី ${data.name}!`}{" "}
            តោះរៀនជាមួយគ្នា!
          </p>
          <p className="hero-description">
            Little steps today. Big discoveries tomorrow.
          </p>
          <button
            className="primary hero-start"
            onClick={() => start(nextLesson(data).id)}
          >
            {data.completed.length ||
            Object.values(data.bookmarks).some((n) => n > 0)
              ? "Continue learning"
              : "Start learning"}
            <ArrowRight size={17} />
          </button>
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="learning-path">
          <header className="section-head">
            <div>
              <div className="heading-with-icon">
                <span className="path-heading-icon">
                  <Route size={21} />
                </span>
                <h2>Your learning path</h2>
              </div>
              <p lang="km" className="km section-km">
                ដំណើររៀនភាសាអង់គ្លេសរបស់អ្នក
              </p>
            </div>
            <span className="unit-count">
              <Layers3 size={13} /> 5 units
            </span>
          </header>
          <div className="path-list">
            <svg
              className="path-trail"
              viewBox="0 0 40 1000"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              <path
                d="M16 72 C16 166 25 193 25 295 S10 417 10 500 S25 615 25 705 S16 826 16 932"
                fill="none"
                stroke="#c8d5cc"
                strokeWidth="2"
                strokeDasharray="3 7"
                strokeLinecap="round"
                vectorEffect="non-scaling-stroke"
              />
            </svg>
            {units.map((u) => (
              <UnitCard key={u.id} unit={u} onClick={() => onUnit(u.id)} />
            ))}
          </div>
          <div className="path-finish">
            <Trophy size={16} />
            <span>One little lesson at a time.</span>
            <span lang="km" className="km">
              មួយមេរៀនម្តងៗ
            </span>
          </div>
        </section>
        <aside className="dashboard-aside">
          <section className="panel daily-card">
            <header className="aside-head">
              <div>
                <h2>
                  <Target size={20} className="green-ink" />
                  Daily goals
                </h2>
                <p lang="km" className="km">
                  គោលដៅប្រចាំថ្ងៃ
                </p>
              </div>
              <button
                className="subtle-arrow"
                onClick={onQuests}
                title="View all quests"
                aria-label="View all daily quests"
              >
                <ChevronRight size={18} />
              </button>
            </header>
            <GoalList />
          </section>
          <section className="word-card">
            <div className="word-eyebrow">
              <Sparkles size={14} /> WORD OF THE DAY
            </div>
            <p className="km word-label" lang="km">
              ពាក្យប្រចាំថ្ងៃ
            </p>
            <div className="word-body">
              <div>
                <h3>{featured.en}</h3>
                <p className="km" lang="km">
                  {featured.km}
                </p>
                <AudioButton text={featured.en} label="Listen" small />
              </div>
              <div className="word-illustration">
                <span>✧</span>
                {featured.en === "Apple" ? (
                  <AppleArt size={104} />
                ) : (
                  <b className="featured-word-icon">{featured.icon}</b>
                )}
                <i>✦</i>
              </div>
            </div>
          </section>
          <div className="gentle-note">
            <span className="leaf-sticker">🌱</span>
            <p>
              Small steps make you grow.
              <span className="km" lang="km">
                រៀនបន្តិចម្តងៗ ដើម្បីរីកចម្រើន។
              </span>
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
export function UnitDetails({
  unit,
  onStart,
}: {
  unit: Unit;
  onStart: (id: string) => void;
}) {
  const { data } = useLearning();
  const open = unitUnlocked(data, unit.id);
  const first = unit.lessons.findIndex((l) => !data.completed.includes(l.id));
  return (
    <>
      <div className="modal-art" style={{ background: unit.tint }}>
        <UnitArt unit={unit.id} size={82} />
      </div>
      <p className="eyebrow" style={{ color: unit.color }}>
        YOUR LEARNING PATH · UNIT {unit.id}
      </p>
      <BiText text={unit.title} as="h2" className="modal-heading" />
      <div className="detail-chips">
        <span>
          <BookOpen size={14} />5 lessons
        </span>
        <span>
          <Clock3 size={14} />
          3–5 min each
        </span>
      </div>
      {!open && (
        <div className="soft-notice">
          <LockKeyhole size={17} />
          <div>
            Finish Unit {unit.id - 1} to unlock this adventure.
            <p className="km" lang="km">
              បញ្ចប់ជំពូកមុន ដើម្បីបើកមេរៀននេះ។
            </p>
          </div>
        </div>
      )}
      <div className="lesson-list">
        {unit.lessons.map((l, i) => {
          const done = data.completed.includes(l.id);
          const locked = !open || (!done && i !== first);
          return (
            <button key={l.id} disabled={locked} onClick={() => onStart(l.id)}>
              <span className={`lesson-index ${done ? "done" : ""}`}>
                {done ? <Check size={17} /> : i + 1}
              </span>
              <span>
                <b>{l.title.en}</b>
                <small className="km" lang="km">
                  {l.title.km}
                </small>
              </span>
              {locked ? <LockKeyhole size={16} /> : <ArrowRight size={17} />}
            </button>
          );
        })}
      </div>
    </>
  );
}
