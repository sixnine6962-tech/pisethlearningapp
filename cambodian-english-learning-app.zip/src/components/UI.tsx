"use client";
import { speak } from "@/lib/audio";
import type { Bilingual } from "@/lib/lessonsData";
import { Check, Turtle, Volume2, VolumeX, X } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
export function AudioButton({
  text,
  slow = false,
  label,
  small = false,
}: {
  text: string;
  slow?: boolean;
  label?: string;
  small?: boolean;
}) {
  const [status, setStatus] = useState<"idle" | "playing" | "unavailable">(
    "idle",
  );
  const reset = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(
    () => () => {
      if (reset.current) clearTimeout(reset.current);
    },
    [],
  );
  return (
    <button
      type="button"
      className={`audio-btn ${small ? "small" : ""} ${label ? "with-label" : ""} ${status === "playing" ? "playing" : ""}`}
      aria-label={`${slow ? "Slow pronunciation" : "Listen"}: ${text}`}
      title={
        status === "unavailable"
          ? "Audio is not available in this browser"
          : `Listen in English: ${text}`
      }
      onClick={(e) => {
        e.stopPropagation();
        const ok = speak(text, slow);
        setStatus(ok ? "playing" : "unavailable");
        if (reset.current) clearTimeout(reset.current);
        reset.current = setTimeout(() => setStatus("idle"), 1600);
      }}
    >
      {status === "unavailable" ? (
        <VolumeX size={small ? 15 : 19} />
      ) : slow ? (
        <Turtle size={small ? 15 : 19} />
      ) : (
        <Volume2 size={small ? 15 : 19} />
      )}{" "}
      {label && <span>{label}</span>}
      {status === "unavailable" && (
        <span className="sr-only" role="status">
          English audio is unavailable on this device.
        </span>
      )}
    </button>
  );
}
export function BiText({
  text,
  audio = true,
  as = "div",
  className = "",
}: {
  text: Bilingual;
  audio?: boolean;
  as?: "div" | "h1" | "h2" | "h3" | "p";
  className?: string;
}) {
  const Tag = as;
  return (
    <div className={`bi-text ${className}`}>
      <div className="bi-en">
        <Tag>{text.en}</Tag>
        {audio && <AudioButton text={text.en} small />}
      </div>
      <p className="km" lang="km">
        {text.km}
      </p>
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
  className = "",
}: {
  title: string;
  children: ReactNode;
  onClose?: () => void;
  wide?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const focused = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = setTimeout(() => {
      (
        ref.current?.querySelector(
          "[autofocus],input:not([disabled]),button:not([disabled])",
        ) as HTMLElement | null
      )?.focus();
    }, 80);
    function key(e: KeyboardEvent) {
      if (e.key === "Escape") onClose?.();
      if (e.key === "Tab" && ref.current) {
        const els = Array.from(
          ref.current.querySelectorAll<HTMLElement>(
            'button:not([disabled]),input:not([disabled]),select,a[href],[tabindex="0"]',
          ),
        ).filter((el) => el.getClientRects().length > 0);
        if (!els.length) return;
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    }
    document.addEventListener("keydown", key);
    return () => {
      clearTimeout(t);
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", key);
      focused?.focus();
    };
  }, [onClose]);
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose?.();
      }}
    >
      <div
        className={`modal ${wide ? "modal-wide" : ""} ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        ref={ref}
      >
        {onClose && (
          <button
            className="modal-close icon-btn"
            aria-label="Close dialog"
            onClick={onClose}
          >
            <X size={19} />
          </button>
        )}
        {children}
      </div>
    </div>
  );
}
export function ProgressBar({
  value,
  max = 100,
  color = "var(--green)",
}: {
  value: number;
  max?: number;
  color?: string;
}) {
  return (
    <div
      className="progress-track"
      role="progressbar"
      aria-valuenow={Math.min(value, max)}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-label="Progress"
    >
      <span
        style={{
          width: `${Math.min(100, Math.max(0, (value / max) * 100))}%`,
          backgroundColor: color,
        }}
      />
    </div>
  );
}
export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onChange}
      className={`toggle ${checked ? "on" : ""}`}
    >
      <span>{checked && <Check size={11} strokeWidth={3} />}</span>
    </button>
  );
}
