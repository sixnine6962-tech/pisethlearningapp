import { storySeeds } from "./storyData";
export type Bilingual = { en: string; km: string };
export type Word = Bilingual & {
  phonetic: string;
  icon: string;
  letter?: string;
};
export type Line = Bilingual & { who: "Tigo" | "Mina" };
type Base = { id: string; prompt: Bilingual };
export type Exercise =
  | (Base & { type: "flashcard"; word: Word })
  | (Base & { type: "picture" | "listening"; word: Word; choices: Word[] })
  | (Base & { type: "pairs"; words: Word[] })
  | (Base & { type: "builder"; sentence: Bilingual; bank: string[] })
  | (Base & { type: "speaking"; word: Word })
  | (Base & {
      type: "story";
      lines: Line[];
      choices: Bilingual[];
      answer: number;
      ending?: Line;
    });
export type Lesson = { id: string; title: Bilingual; questions: Exercise[] };
export type Unit = {
  id: number;
  title: Bilingual;
  color: string;
  tint: string;
  lessons: Lesson[];
};
export const bi = (en: string, km: string): Bilingual => ({ en, km });
const words = (source: string): Word[] =>
  source.split("\n").map((line) => {
    const [en, km, phonetic, icon] = line.split("|");
    return { en, km, phonetic, icon };
  });
const alphabet = words(`Apple|ផ្លែប៉ោម|អែបផល|🍎
Ball|បាល់|បល|⚽
Cat|ឆ្មា|ខែត|🐈
Dog|ឆ្កែ|ដក|🐶
Egg|ស៊ុត|អេក|🥚
Fish|ត្រី|ហ្វីស|🐟
Goat|ពពែ|ហ្គោត|🐐
Hat|មួក|ហែត|👒
Ice|ទឹកកក|អាយស៍|🧊
Juice|ទឹកផ្លែឈើ|ជូស|🧃
Kite|ខ្លែង|ខាយត៍|🪁
Lion|តោ|ឡាយអិន|🦁
Moon|ព្រះចន្ទ|មូន|🌙
Nest|សំបុក|ណេស្ត៍|🪺
Orange|ក្រូច|អ័ររីនជ៍|🍊
Panda|ខ្លាឃ្មុំផេនដា|ផែនដា|🐼
Queen|មហាក្សត្រី|ឃ្វីន|👸
Rabbit|ទន្សាយ|រ៉ែប៊ីត|🐰
Sun|ព្រះអាទិត្យ|សាន់|☀️
Tiger|ខ្លា|ថាយហ្គើ|🐯
Umbrella|ឆ័ត្រ|អាំប្រេឡា|☂️
Van|ឡានតូច|វែន|🚐
Water|ទឹក|វ៉តធើ|💧
Xylophone|រនាត|ហ្សាយឡូហ្វូន|🎵
Yo-yo|យ៉ូយ៉ូ|យ៉ូយ៉ូ|🪀
Zebra|សេះបង្កង់|ហ្ស៊ីប្រា|🦓`).map((w, i) => ({
  ...w,
  letter: String.fromCharCode(65 + i),
}));
const greetings = words(`Hello|សួស្តី|ហេឡូ|👋
Good morning|អរុណសួស្តី|ហ្គូដ ម៉រនីង|🌅
Good night|រាត្រីសួស្តី|ហ្គូដ ណាយត៍|🌙
Goodbye|លាហើយ|ហ្គូដបាយ|👋
Welcome|សូមស្វាគមន៍|វែលខាំ|🤗
Please|សូម|ផ្លីស|🙏
Thank you|អរគុណ|ថែងឃ្យូ|💝
Sorry|សុំទោស|សរី|🙇
Excuse me|អត់ទោស|អិចស្គ្យូស មី|🙋
You are welcome|មិនអីទេ|យូ អារ វែលខាំ|😊
Happy|រីករាយ|ហែបភី|😄
Sad|សោកសៅ|សែដ|😢
Sleepy|ងងុយគេង|ស្ល៊ីពី|🥱
Excited|រំភើប|អិចសាយធីដ|🤩
Fine|សុខសប្បាយ|ហ្វាញ|🙂
Friend|មិត្តភក្តិ|ហ្វ្រេនដ៍|🧒
Teacher|គ្រូ|ធីឈើ|👩‍🏫
Mother|ម្តាយ|ម៉ាធើ|👩
Father|ឪពុក|ហ្វាធើ|👨
Baby|ទារក|បេប៊ី|👶
Yes|បាទ ឬ ចាស|យេស|✅
No|ទេ|ណូ|🙅
Okay|យល់ព្រម|អូខេ|👌
See you|ជួបគ្នាពេលក្រោយ|ស៊ី យូ|👋
Take care|ថែរក្សាខ្លួន|ថេក ខែរ|💛`);
const animals = words(`Cat|ឆ្មា|ខែត|🐱
Dog|ឆ្កែ|ដក|🐶
Bird|បក្សី|ប៊ើដ|🐦
Fish|ត្រី|ហ្វីស|🐟
Rabbit|ទន្សាយ|រ៉ែប៊ីត|🐰
Cow|គោ|ខៅ|🐮
Pig|ជ្រូក|ភីក|🐷
Duck|ទា|ដាក់|🦆
Sheep|ចៀម|ស៊ីប|🐑
Horse|សេះ|ហស|🐴
Tiger|ខ្លា|ថាយហ្គើ|🐯
Elephant|ដំរី|អេលីហ្វិនត៍|🐘
Monkey|ស្វា|ម៉ាំងឃី|🐒
Lion|តោ|ឡាយអិន|🦁
Bear|ខ្លាឃ្មុំ|បែរ|🐻
Red|ក្រហម|រ៉េដ|🔴
Blue|ខៀវ|ប្ល៊ូ|🔵
Green|បៃតង|ហ្គ្រីន|🟢
Yellow|លឿង|យែលឡូ|🟡
Purple|ស្វាយ|ភើផល|🟣
Pink|ផ្កាឈូក|ភីងក៍|🩷
Black|ខ្មៅ|ប្លែក|⚫
White|ស|វ៉ាយត៍|⚪
Brown|ត្នោត|ប្រោន|🟤
Orange|ទឹកក្រូច|អ័ររីនជ៍|🟠`);
const fruits = words(`One|មួយ|វ័ន|1️⃣
Two|ពីរ|ធូ|2️⃣
Three|បី|ស្រី|3️⃣
Four|បួន|ហ្វរ|4️⃣
Five|ប្រាំ|ហ្វាយវ៍|5️⃣
Six|ប្រាំមួយ|ស៊ីកស៍|6️⃣
Seven|ប្រាំពីរ|សេវិន|7️⃣
Eight|ប្រាំបី|អេត|8️⃣
Nine|ប្រាំបួន|ណាញ|9️⃣
Ten|ដប់|ថេន|🔟
Apple|ផ្លែប៉ោម|អែបផល|🍎
Banana|ចេក|បាណាណា|🍌
Mango|ស្វាយ|ម៉ែងហ្គោ|🥭
Orange|ក្រូច|អ័ររីនជ៍|🍊
Grape|ទំពាំងបាយជូរ|ហ្គ្រេប|🍇
Watermelon|ឪឡឹក|វ៉ធើមែលិន|🍉
Pineapple|ម្នាស់|ផាញអែបផល|🍍
Coconut|ដូង|ខូខូណាត់|🥥
Strawberry|ស្ត្របឺរី|ស្ត្រប៊ែរី|🍓
Peach|ផ្លែប៉ែស|ភីច|🍑
Basket|កន្ត្រក|បាស្កិត|🧺
Market|ផ្សារ|ម៉ារឃិត|🏪
Fruit|ផ្លែឈើ|ហ្វ្រូត|🍒
Juice|ទឹកផ្លែឈើ|ជូស|🧃
Shop|ហាង|សប|🏬`);
const everyday = words(`Book|សៀវភៅ|ប៊ុក|📘
Pen|ប៊ិក|ផេន|🖊️
Pencil|ខ្មៅដៃ|ផេនស៊ល|✏️
Bag|កាបូប|ប៊ែក|🎒
School|សាលារៀន|ស្គូល|🏫
Rice|បាយ|រ៉ាយស៍|🍚
Water|ទឹក|វ៉តធើ|💧
Milk|ទឹកដោះគោ|មីលក៍|🥛
Bread|នំប៉័ង|ប្រេដ|🍞
Soup|ស៊ុប|ស៊ូប|🍲
House|ផ្ទះ|ហៅស៍|🏠
Bed|គ្រែ|បេដ|🛏️
Chair|កៅអី|ឆែរ|🪑
Door|ទ្វារ|ដរ|🚪
Window|បង្អួច|វីនដូ|🪟
Read|អាន|រីដ|📖
Draw|គូរ|ដ្រ|🎨
Sing|ច្រៀង|ស៊ីង|🎤
Play|លេង|ផ្លេ|🧸
Run|រត់|រ៉ាន់|🏃
Sunny|មានពន្លឺថ្ងៃ|សាន់នី|☀️
Rainy|មានភ្លៀង|រេននី|🌧️
Cloudy|មានពពក|ក្លៅឌី|☁️
Windy|មានខ្យល់|វីនឌី|🌬️
Hot|ក្តៅ|ហត|🌡️`);
// Each topic introduces its vocabulary before asking the child to recall it.
// All 25 lessons include picture, listening, matching, building, speech, and story practice.
type Topic = [string, string, string, string];
const topics: Topic[][] = [
  [
    ["Letters A–E", "អក្សរ A ដល់ E", "I see a cat", "ខ្ញុំឃើញឆ្មាមួយក្បាល"],
    ["Letters F–J", "អក្សរ F ដល់ J", "I like fish", "ខ្ញុំចូលចិត្តត្រី"],
    ["Letters K–O", "អក្សរ K ដល់ O", "It is a kite", "វាជាខ្លែងមួយ"],
    [
      "Letters P–T",
      "អក្សរ P ដល់ T",
      "The sun is bright",
      "ព្រះអាទិត្យភ្លឺចែងចាំង",
    ],
    ["Letters U–Z", "អក្សរ U ដល់ Z", "I drink water", "ខ្ញុំផឹកទឹក"],
  ],
  [
    [
      "First greetings",
      "ការស្វាគមន៍ដំបូង",
      "Hello my friend",
      "សួស្តីមិត្តរបស់ខ្ញុំ",
    ],
    ["Kind little words", "ពាក្យគួរសម", "Thank you very much", "សូមអរគុណច្រើន"],
    ["How you feel", "អារម្មណ៍របស់អ្នក", "I am happy", "ខ្ញុំសប្បាយចិត្ត"],
    [
      "Meeting people",
      "ជួបមនុស្សថ្មី",
      "She is my teacher",
      "គាត់ជាគ្រូរបស់ខ្ញុំ",
    ],
    ["See you soon", "ជួបគ្នាឆាប់ៗ", "See you tomorrow", "ជួបគ្នាថ្ងៃស្អែក"],
  ],
  [
    [
      "Our little pets",
      "សត្វចិញ្ចឹមរបស់យើង",
      "I have a dog",
      "ខ្ញុំមានឆ្កែមួយក្បាល",
    ],
    ["On the farm", "នៅកសិដ្ឋាន", "I see a duck", "ខ្ញុំឃើញទាមួយក្បាល"],
    ["In the jungle", "ក្នុងព្រៃ", "The tiger is big", "ខ្លាមានមាឌធំ"],
    ["Rainbow colors", "ពណ៌ឥន្ទធនូ", "The leaf is green", "ស្លឹកឈើមានពណ៌បៃតង"],
    [
      "More colors",
      "ពណ៌ផ្សេងទៀត",
      "My bag is pink",
      "កាបូបរបស់ខ្ញុំពណ៌ផ្កាឈូក",
    ],
  ],
  [
    [
      "Count to five",
      "រាប់ដល់ប្រាំ",
      "I have two apples",
      "ខ្ញុំមានផ្លែប៉ោមពីរផ្លែ",
    ],
    ["Count to ten", "រាប់ដល់ដប់", "I see ten stars", "ខ្ញុំឃើញផ្កាយដប់"],
    [
      "Favorite fruits",
      "ផ្លែឈើដែលចូលចិត្ត",
      "I like mangoes",
      "ខ្ញុំចូលចិត្តផ្លែស្វាយ",
    ],
    ["Tropical treats", "ផ្លែឈើឆ្ងាញ់ៗ", "This coconut is big", "ដូងនេះធំ"],
    ["At the market", "នៅផ្សារ", "I buy some fruit", "ខ្ញុំទិញផ្លែឈើខ្លះ"],
  ],
  [
    ["At school", "នៅសាលារៀន", "This is my book", "នេះជាសៀវភៅរបស់ខ្ញុំ"],
    ["Time to eat", "ដល់ម៉ោងញ៉ាំ", "I would like rice", "ខ្ញុំចង់ញ៉ាំបាយ"],
    ["At home", "នៅផ្ទះ", "Please open the door", "សូមបើកទ្វារ"],
    ["Play together", "លេងជាមួយគ្នា", "I like to draw", "ខ្ញុំចូលចិត្តគូររូប"],
    ["The weather", "អាកាសធាតុ", "It is sunny today", "ថ្ងៃនេះមានពន្លឺថ្ងៃ"],
  ],
];
const unitInfo = [
  ["Alphabet & Phonics", "អក្ខរក្រម និងសំឡេង", "#299d72", "#eaf6eb"],
  [
    "Greetings & Polite Words",
    "ការសួរសុខទុក្ខ និងពាក្យគួរសម",
    "#dd9951",
    "#fff2df",
  ],
  ["Animals & Colors", "សត្វ និងពណ៌", "#9383cf", "#f0ebfb"],
  ["Numbers & Fruits", "លេខ និងផ្លែឈើ", "#e37f82", "#fff0ed"],
  ["Everyday Conversations", "ការសន្ទនាប្រចាំថ្ងៃ", "#5b9dcc", "#e9f4ff"],
];
export const wordBanks = [alphabet, greetings, animals, fruits, everyday];
export const units: Unit[] = unitInfo.map(([en, km, color, tint], u) => ({
  id: u + 1,
  title: bi(en, km),
  color,
  tint,
  lessons: topics[u].map(([title, titleKm, sentence, sentenceKm], l) => {
    const id = `u${u + 1}-l${l + 1}`;
    const group: Word[] = wordBanks[u].slice(
      l * 5,
      l === 4 ? undefined : l * 5 + 5,
    );
    const target = group[l % group.length];
    const listen = group[(l + 2) % group.length];
    const choices = (w: Word) => {
      const opts = [w, ...group.filter((g) => g.en !== w.en).slice(0, 3)];
      const shift = (u + l + 1) % 4;
      return [...opts.slice(shift), ...opts.slice(0, shift)];
    };
    const tokens = sentence.split(" ");
    const bank = [
      ...tokens.filter((_, i) => i % 2 === 1).reverse(),
      ...tokens.filter((_, i) => i % 2 === 0).reverse(),
    ];
    const story = storySeeds[u][l];
    const storyAnswer = (u + l + 1) % 3;
    const storyChoices = Array.from(
      { length: 3 },
      (_, i) => group[(story[6] + ((i - storyAnswer + 3) % 3)) % group.length],
    );
    const usePhrase = u === 4 || l >= 2;
    const listeningWord: Word = usePhrase
      ? { en: sentence, km: sentenceKm, phonetic: "", icon: "💬" }
      : listen;
    const phraseOptions = [
      listeningWord,
      ...topics[u]
        .filter((t) => t[2] !== sentence)
        .slice(0, 3)
        .map((t) => ({ en: t[2], km: t[3], phonetic: "", icon: "💬" })),
    ];
    const listeningChoices = usePhrase
      ? Array.from({ length: 4 }, (_, i) => phraseOptions[(i + u + l) % 4])
      : choices(listen);
    const questions: Exercise[] = [
      ...group.map(
        (w, i): Exercise => ({
          id: `${id}-f${i}`,
          type: "flashcard",
          word: w,
          prompt: w.letter
            ? bi(`Meet the letter ${w.letter}`, `មកស្គាល់អក្សរ ${w.letter}`)
            : bi("Meet a new word", "មកស្គាល់ពាក្យថ្មី"),
        }),
      ),
      {
        id: id + "-picture",
        type: "picture",
        prompt: bi(`Which one is “${target.en}”?`, `តើមួយណាជា «${target.km}»?`),
        word: target,
        choices: choices(target),
      },
      {
        id: id + "-listen",
        type: "listening",
        prompt: usePhrase
          ? bi(
              "Listen and choose the sentence",
              "ស្តាប់ រួចជ្រើសរើសប្រយោគដែលត្រូវ",
            )
          : bi("Listen and choose the word", "ស្តាប់ រួចជ្រើសរើសពាក្យដែលត្រូវ"),
        word: listeningWord,
        choices: listeningChoices,
      },
      {
        id: id + "-pairs",
        type: "pairs",
        prompt: bi("Match the five pairs", "ផ្គូផ្គងពាក្យទាំងប្រាំគូ"),
        words: group.slice(0, 5),
      },
      {
        id: id + "-build",
        type: "builder",
        prompt: bi("Build the English sentence", "រៀបពាក្យជាប្រយោគអង់គ្លេស"),
        sentence: bi(sentence, sentenceKm),
        bank,
      },
      {
        id: id + "-speak",
        type: "speaking",
        prompt: bi("Say it with Tigo", "និយាយជាមួយទីហ្គោ"),
        word: group[0],
      },
      {
        id: id + "-story",
        type: "story",
        prompt: bi(story[4], story[5]),
        lines: [
          { who: "Tigo", ...bi(story[0], story[1]) },
          { who: "Mina", ...bi(story[2], story[3]) },
        ],
        choices: storyChoices,
        answer: storyAnswer,
        ending: { who: "Tigo", ...bi(story[7], story[8]) },
      },
    ];
    return { id, title: bi(title, titleKm), questions };
  }),
}));
// Dedicated conversational stories include an in-context comprehension checkpoint.
export const conversations: {
  title: Bilingual;
  icon: string;
  tint: string;
  lines: Line[];
  prompt: Bilingual;
  choices: Bilingual[];
  answer: number;
  ending: Line;
}[] = [
  {
    title: bi("A friendly hello", "ការសួរសុខទុក្ខ"),
    icon: "👋",
    tint: "#fff0d9",
    lines: [
      {
        who: "Tigo",
        ...bi("Hello! My name is Tigo.", "សួស្តី! ខ្ញុំឈ្មោះទីហ្គោ។"),
      },
      {
        who: "Mina",
        ...bi("Hi, Tigo! I am Mina.", "សួស្តី ទីហ្គោ! ខ្ញុំឈ្មោះមីណា។"),
      },
      {
        who: "Tigo",
        ...bi("Nice to meet you, Mina!", "រីករាយដែលបានជួបអ្នក មីណា!"),
      },
    ],
    prompt: bi("What is the girl’s name?", "តើក្មេងស្រីនោះឈ្មោះអ្វី?"),
    choices: [bi("Mina", "មីណា"), bi("Tigo", "ទីហ្គោ"), bi("Dara", "ដារ៉ា")],
    answer: 0,
    ending: {
      who: "Mina",
      ...bi("Nice to meet you too!", "ខ្ញុំក៏រីករាយដែលបានជួបអ្នកដែរ!"),
    },
  },
  {
    title: bi("At the fruit market", "នៅផ្សារផ្លែឈើ"),
    icon: "🍎",
    tint: "#fbe7e2",
    lines: [
      {
        who: "Mina",
        ...bi(
          "Good morning! Two apples, please.",
          "អរុណសួស្តី! សូមផ្លែប៉ោមពីរផ្លែ។",
        ),
      },
      { who: "Tigo", ...bi("Here are your apples.", "នេះជាផ្លែប៉ោមរបស់អ្នក។") },
    ],
    prompt: bi(
      "How many apples does Mina want?",
      "តើមីណាចង់បានផ្លែប៉ោមប៉ុន្មានផ្លែ?",
    ),
    choices: [bi("One", "មួយ"), bi("Two", "ពីរ"), bi("Three", "បី")],
    answer: 1,
    ending: { who: "Mina", ...bi("Thank you very much!", "អរគុណច្រើន!") },
  },
  {
    title: bi("A day at school", "មួយថ្ងៃនៅសាលា"),
    icon: "🎒",
    tint: "#e6edfc",
    lines: [
      {
        who: "Tigo",
        ...bi("What is in your bag?", "តើមានអ្វីនៅក្នុងកាបូបរបស់អ្នក?"),
      },
      {
        who: "Mina",
        ...bi("I have a blue book.", "ខ្ញុំមានសៀវភៅពណ៌ខៀវមួយក្បាល។"),
      },
    ],
    prompt: bi("What color is the book?", "តើសៀវភៅមានពណ៌អ្វី?"),
    choices: [bi("Red", "ក្រហម"), bi("Green", "បៃតង"), bi("Blue", "ខៀវ")],
    answer: 2,
    ending: {
      who: "Tigo",
      ...bi("Let’s read together!", "តោះយើងអានជាមួយគ្នា!"),
    },
  },
];
export const exerciseCount = units.reduce(
  (sum, u) => sum + u.lessons.reduce((n, l) => n + l.questions.length, 0),
  0,
);
export const findLesson = (id: string) =>
  units.flatMap((u) => u.lessons).find((l) => l.id === id);
