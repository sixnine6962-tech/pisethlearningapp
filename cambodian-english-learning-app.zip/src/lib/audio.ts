"use client";
let context: AudioContext | null = null;
export function primeAudio() {
  try {
    const Audio =
      window.AudioContext ||
      (window as Window & { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!Audio) return;
    context ??= new Audio();
    if (context.state === "suspended") void context.resume().catch(() => {});
  } catch {
    /* Visual feedback is always available. */
  }
}
export function speak(text: string, slow = false) {
  if (typeof window === "undefined" || !("speechSynthesis" in window))
    return false;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.rate = slow ? 0.62 : 0.86;
    utterance.pitch = 1.08;
    const voice = window.speechSynthesis
      .getVoices()
      .find((v) => v.lang === "en-US");
    if (voice) utterance.voice = voice;
    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    return false;
  }
}
export function sound(kind: "correct" | "wrong" | "level" | "bell") {
  primeAudio();
  if (!context) return;
  const ctx = context;
  const notes =
    kind === "bell"
      ? [784, 1568, 2352]
      : kind === "correct"
        ? [523.25, 783.99]
        : kind === "level"
          ? [523.25, 659.25, 783.99, 1046.5]
          : [246.94, 220];
  notes.forEach((hz, i) => {
    const osc = ctx.createOscillator(),
      gain = ctx.createGain();
    const start = ctx.currentTime + (kind === "bell" ? 0 : i * 0.13),
      duration = kind === "bell" ? 2.4 : 0.3;
    osc.type = "sine";
    osc.frequency.value = hz;
    gain.gain.setValueAtTime(0.001, start);
    gain.gain.exponentialRampToValueAtTime(
      kind === "bell" ? 0.23 / (i + 1) : 0.12,
      start + 0.012,
    );
    gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.01);
  });
}
