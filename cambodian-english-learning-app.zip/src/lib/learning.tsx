"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { primeAudio, sound } from "./audio";
import { findLesson } from "./lessonsData";
import {
  bedtimeLocked,
  dayKey,
  initialLearner,
  remaining,
  rollDay,
  sanitizeLearner,
  STORAGE_KEY,
  usedMs,
  type Learner,
  type Study,
} from "./model";
export async function notifyParent(title: string, body: string) {
  if (
    typeof Notification === "undefined" ||
    Notification.permission !== "granted"
  )
    return;
  try {
    const reg =
      "serviceWorker" in navigator
        ? await navigator.serviceWorker.getRegistration()
        : null;
    if (reg)
      await reg.showNotification(title, {
        body,
        icon: "/icon.svg",
        tag: "piseth-learning",
      });
    else new Notification(title, { body, icon: "/icon.svg" });
  } catch {
    /* The visible rest screen works without notifications. */
  }
}
type Store = {
  data: Learner;
  ready: boolean;
  seconds: number;
  now: number;
  sync: string;
  update: (fn: (s: Learner) => Learner) => void;
  start: (id: string, mode?: Study["mode"], activity?: number) => void;
  end: () => void;
  advance: (wasSpeech?: boolean) => void;
  finish: (wasSpeech?: boolean) => void;
  toast: (text: string) => void;
  message: string;
};
const Context = createContext<Store | null>(null);
export function LearningProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Learner>(initialLearner);
  const [ready, setReady] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [message, setMessage] = useState("");
  const [sync, setSync] = useState("device");
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const update = useCallback(
    (fn: (s: Learner) => Learner) =>
      setData((s) => ({ ...fn(s), updatedAt: Date.now() })),
    [],
  );
  const toast = useCallback((text: string) => {
    setMessage(text);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setMessage(""), 4000);
  }, []);
  useEffect(() => {
    let cancelled = false;
    // Restore the device snapshot after the server-rendered guest view hydrates.
    queueMicrotask(() => {
      if (cancelled) return;
      let local = initialLearner();
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) local = sanitizeLearner(JSON.parse(raw));
      } catch {
        /* Invalid or inaccessible storage starts a clean local profile. */
      }
      setData(local);
      setReady(true);
      if (local.account !== "guest")
        fetch("/api/progress")
          .then(async (r) => {
            if (r.ok) {
              const b = await r.json();
              if (!cancelled && b.progress) {
                const cloud = sanitizeLearner(b.progress);
                setData((s) => (cloud.updatedAt > s.updatedAt ? cloud : s));
              }
            } else if (r.status === 401 && !cancelled) setSync("sign-in");
          })
          .catch(() => {});
    });
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          const v = sanitizeLearner(JSON.parse(e.newValue));
          setData((s) => (v.updatedAt > s.updatedAt ? v : s));
        } catch {}
      }
    };
    window.addEventListener("storage", onStorage);
    if ("serviceWorker" in navigator)
      void navigator.serviceWorker.register("/sw.js").catch(() => {});
    return () => {
      cancelled = true;
      window.removeEventListener("storage", onStorage);
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      queueMicrotask(() =>
        toast("Device storage is unavailable. Keep this page open."),
      );
    }
    if (data.account === "guest") return;
    const abort = new AbortController();
    const t = setTimeout(async () => {
      setSync("saving");
      try {
        const r = await fetch("/api/progress", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
          signal: abort.signal,
        });
        setSync(r.ok ? "synced" : r.status === 401 ? "sign-in" : "offline");
      } catch {
        if (!abort.signal.aborted) setSync("offline");
      }
    }, 650);
    return () => {
      clearTimeout(t);
      abort.abort();
    };
  }, [data, ready, toast]);
  const seconds = remaining(data, now);
  const bellKey = useRef("");
  useEffect(() => {
    if (!ready) return;
    // The wall clock, not the number of timer callbacks, is the source of truth.
    const tick = () => {
      const time = Date.now();
      const date = new Date(time);
      const remainingSeconds = remaining(data, time);
      setNow(time);
      const rolled = rollDay(data, date);
      if (rolled !== data) {
        update(() => rolled);
        return;
      }
      const bed = bedtimeLocked(data, date);
      if (!data.rest && (remainingSeconds <= 0 || bed)) {
        const reason = bed ? "bedtime" : "time";
        if (data.session) {
          const token = data.day + ":" + data.session.clockAt;
          if (bellKey.current !== token) {
            bellKey.current = token;
            window.speechSynthesis?.cancel();
            sound("bell");
            void notifyParent(
              "PisethLearning · Time to rest",
              "អស់ម៉ោងរៀនហើយ! Your child’s learning session has finished.",
            );
          }
        }
        update((s) => ({
          ...s,
          session: null,
          rest: reason,
          spentMs: Math.min((s.limit + s.bonus) * 60000, usedMs(s, time)),
        }));
        return;
      }
      const hhmm = `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
      if (
        data.reminder &&
        !data.session &&
        !data.rest &&
        data.lastReminder !== data.day &&
        hhmm === data.reminderAt
      ) {
        void notifyParent(
          "Time for a little English!",
          "ដល់ម៉ោងរៀនហើយ! Tigo is ready for today’s adventure.",
        );
        update((s) => ({ ...s, lastReminder: s.day }));
      }
    };
    const initialTick = setTimeout(tick, 0);
    const timer = setInterval(tick, data.session ? 500 : 10000);
    document.addEventListener("visibilitychange", tick);
    return () => {
      clearTimeout(initialTick);
      clearInterval(timer);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [data, ready, update]);
  const active = !!data.session;

  useEffect(() => {
    if (!active) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [active]);
  const start = useCallback(
    (id: string, mode: Study["mode"] = "lesson", activity = 0) => {
      if (!findLesson(id)) return;
      primeAudio();
      window.speechSynthesis?.cancel();
      const t = Date.now();
      setNow(t);
      update((s) => {
        if (s.rest || remaining(s, t) <= 0 || bedtimeLocked(s, new Date(t)))
          return {
            ...s,
            rest: bedtimeLocked(s, new Date(t)) ? "bedtime" : "time",
            session: null,
          };
        return {
          ...s,
          session: {
            lessonId: id,
            index: mode === "lesson" ? s.bookmarks[id] || 0 : 0,
            clockAt: s.session?.clockAt || t,
            stage: "learning",
            mode,
            activity,
          },
        };
      });
    },
    [update],
  );
  const end = useCallback(() => {
    window.speechSynthesis?.cancel();
    update((s) => ({ ...s, spentMs: usedMs(s, Date.now()), session: null }));
  }, [update]);
  const finish = useCallback(
    (wasSpeech = false) => {
      update((s) => {
        if (!s.session || s.session.stage === "complete") return s;
        const sess = s.session,
          isLesson = sess.mode === "lesson",
          fresh = isLesson && !s.completed.includes(sess.lessonId),
          reward = fresh ? 20 : 10;
        return {
          ...s,
          bookmarks: isLesson
            ? { ...s.bookmarks, [sess.lessonId]: 0 }
            : s.bookmarks,
          session: { ...sess, stage: "complete" },
          completed: fresh ? [...s.completed, sess.lessonId] : s.completed,
          xp: s.xp + reward,
          weeklyXp: s.weeklyXp + reward,
          gems: s.gems + (fresh ? 5 : 2),
          dates: [...new Set([...s.dates, dayKey()])].slice(-730),
          spoken: s.spoken + (wasSpeech ? 1 : 0),
          daily: {
            ...s.daily,
            xp: s.daily.xp + reward,
            lessons: s.daily.lessons + (isLesson ? 1 : 0),
            speaking: s.daily.speaking + (wasSpeech ? 1 : 0),
          },
        };
      });
    },
    [update],
  );
  const advance = useCallback(
    (wasSpeech = false) => {
      update((s) =>
        !s.session
          ? s
          : {
              ...s,
              bookmarks:
                s.session.mode === "lesson"
                  ? {
                      ...s.bookmarks,
                      [s.session.lessonId]: s.session.index + 1,
                    }
                  : s.bookmarks,
              session: { ...s.session, index: s.session.index + 1 },
              spoken: s.spoken + (wasSpeech ? 1 : 0),
              daily: {
                ...s.daily,
                speaking: s.daily.speaking + (wasSpeech ? 1 : 0),
              },
            },
      );
    },
    [update],
  );
  return (
    <Context.Provider
      value={{
        data,
        ready,
        now,
        seconds,
        sync: data.account === "guest" ? "device" : sync,
        update,
        start,
        end,
        advance,
        finish,
        toast,
        message,
      }}
    >
      {children}
    </Context.Provider>
  );
}
export function useLearning() {
  const ctx = useContext(Context);
  if (!ctx) throw new Error("LearningProvider is required");
  return ctx;
}
