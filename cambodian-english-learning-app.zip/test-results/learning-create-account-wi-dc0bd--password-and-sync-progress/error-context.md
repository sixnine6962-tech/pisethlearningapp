# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: learning.spec.ts >> create account with email and password, sign in, update password and sync progress
- Location: tests/learning.spec.ts:186:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('dialog').getByRole('button', { name: 'Sign in · ចូលប្រើគណនី' })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - complementary [ref=e3]:
      - button "PisethLearning home" [ref=e4] [cursor=pointer]:
        - img "Tigo the tiger" [ref=e5]
        - generic [ref=e26]:
          - strong [ref=e27]: PisethLearning
          - generic [ref=e28]: ENGLISH FOR KIDS
      - generic [ref=e29]:
        - generic [ref=e30]: MY CLASSROOM
        - navigation "Main navigation" [ref=e31]:
          - button "Learn មេរៀន" [ref=e32] [cursor=pointer]:
            - generic [ref=e36]:
              - generic [ref=e37]: Learn
              - generic [ref=e38]: មេរៀន
          - button "Speak & Chat សន្ទនា" [ref=e39] [cursor=pointer]:
            - generic [ref=e43]:
              - generic [ref=e44]: Speak & Chat
              - generic [ref=e45]: សន្ទនា
          - button "Leaderboard តារាងពិន្ទុ" [ref=e46] [cursor=pointer]:
            - generic [ref=e54]:
              - generic [ref=e55]: Leaderboard
              - generic [ref=e56]: តារាងពិន្ទុ
          - button "Quests បេសកកម្ម" [ref=e57] [cursor=pointer]:
            - generic [ref=e63]:
              - generic [ref=e64]: Quests
              - generic [ref=e65]: បេសកកម្ម
          - button "Profile គណនី" [ref=e66] [cursor=pointer]:
            - generic [ref=e71]:
              - generic [ref=e72]: Profile
              - generic [ref=e73]: គណនី
        - generic [ref=e75]:
          - button "Parents’ corner សម្រាប់អាណាព្យាបាល" [ref=e76] [cursor=pointer]:
            - generic [ref=e81]:
              - generic [ref=e82]: Parents’ corner
              - generic [ref=e83]: សម្រាប់អាណាព្យាបាល
          - generic [ref=e86]: "MadeBy: TryPiseth.LLC"
    - generic [ref=e88]:
      - banner [ref=e89]:
        - button "English course flag English course" [ref=e90] [cursor=pointer]:
          - img "English course flag" [ref=e91]
          - generic [ref=e98]: English course
        - generic [ref=e101]:
          - button "0 day streak" [ref=e102] [cursor=pointer]:
            - generic [ref=e106]: "0"
          - button "50 gems" [ref=e107] [cursor=pointer]:
            - generic [ref=e117]: "50"
          - button "5 hearts" [ref=e118] [cursor=pointer]:
            - generic [ref=e121]: "5"
          - button "View remaining learning time" [ref=e122] [cursor=pointer]:
            - generic [ref=e126]: Time left
            - generic [ref=e127]: 05:00
          - button "Open learner profile" [ref=e129] [cursor=pointer]:
            - img "Tigo the tiger" [ref=e131]
      - main [ref=e154]:
        - generic [ref=e155]:
          - generic [ref=e156]: MY LEARNING SPACE
          - generic [ref=e160]:
            - generic [ref=e161]:
              - heading "Learner profile" [level=1] [ref=e162]
              - 'button "Listen: Learner profile" [ref=e163] [cursor=pointer]'
            - paragraph [ref=e168]: គណនីអ្នកសិក្សា
          - generic [ref=e169]:
            - img "Tigo the tiger" [ref=e171]
            - generic [ref=e192]:
              - text: LITTLE EXPLORER
              - heading "Dara" [level=2] [ref=e193]
              - paragraph [ref=e194]: Guest learner · Learning on this device
              - generic [ref=e195]: Progress saved on this device
            - generic [ref=e199]: Level 1
          - generic [ref=e202]:
            - generic [ref=e203]:
              - generic [ref=e206]: "0"
              - generic [ref=e207]: Total XP
            - generic [ref=e208]:
              - generic [ref=e212]: "0"
              - generic [ref=e213]: Day streak
            - generic [ref=e214]:
              - generic [ref=e217]: 0/25
              - generic [ref=e218]: Lessons learned
            - generic [ref=e219]:
              - generic [ref=e229]: "50"
              - generic [ref=e230]: Gems collected
          - generic [ref=e231]:
            - generic [ref=e232]:
              - generic [ref=e237]:
                - generic [ref=e238]:
                  - heading "Parents’ corner" [level=3] [ref=e239]
                  - 'button "Listen: Parents’ corner" [ref=e240] [cursor=pointer]'
                - paragraph [ref=e245]: សម្រាប់អាណាព្យាបាល
              - paragraph [ref=e246]: Daily limits, bedtime, reminders, and your family PIN.
              - generic [ref=e247]: 05:00 remaining today
              - button "Parental controls" [ref=e251] [cursor=pointer]
            - generic [ref=e258]:
              - generic [ref=e263]:
                - generic [ref=e264]:
                  - heading "Explorer shop" [level=3] [ref=e265]
                  - 'button "Listen: Explorer shop" [ref=e266] [cursor=pointer]'
                - paragraph [ref=e271]: ហាងអ្នករុករក
              - paragraph [ref=e272]: Spend your learning gems on a new animal buddy.
              - generic [ref=e273]: 50 gems available
              - button "Visit the shop" [ref=e283] [cursor=pointer]
          - generic [ref=e286]:
            - generic [ref=e291]:
              - heading "Save your learning adventure" [level=3] [ref=e292]
              - paragraph [ref=e293]: បង្កើតគណនី ដើម្បីរក្សាទុកការសិក្សា។
            - button "Sign in / Create account" [ref=e294] [cursor=pointer]
          - paragraph [ref=e297]: "PisethLearning · 5 units · 276 activitiesMadeBy: TryPiseth.LLC"
  - alert [ref=e298]
  - dialog "Parent PIN" [ref=e300]:
    - button "Close dialog" [active] [ref=e301] [cursor=pointer]
    - generic [ref=e305]:
      - text: GROWN-UPS ONLY
      - generic [ref=e310]:
        - generic [ref=e311]:
          - heading "Parent PIN" [level=2] [ref=e312]
          - 'button "Listen: Parent PIN" [ref=e313] [cursor=pointer]'
        - paragraph [ref=e318]: លេខសម្ងាត់អាណាព្យាបាល
      - generic [ref=e319]:
        - generic [ref=e320]:
          - generic [ref=e321]: Enter your PIN to manage the family account.
          - 'button "Listen: Enter your PIN to manage the family account." [ref=e322] [cursor=pointer]'
        - paragraph [ref=e327]: សូមឱ្យអាណាព្យាបាលបញ្ចូលលេខសម្ងាត់ ៤ ខ្ទង់។
      - generic [ref=e328]:
        - generic [ref=e329]:
          - text: 4-digit Parent PIN
          - generic [ref=e330]: លេខសម្ងាត់ ៤ ខ្ទង់
        - textbox "4-digit Parent PIN លេខសម្ងាត់ ៤ ខ្ទង់" [ref=e331]:
          - /placeholder: • • • •
        - button "Unlock · បើកសោ" [disabled] [ref=e332]
```

# Test source

```ts
  134 |   await page.locator(".answer-pick").filter({ hasText: "Cat" }).click();
  135 |   await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  136 |   await page.getByRole("button", { name: "Continue បន្ត" }).click();
  137 |   for (const [en, km] of [
  138 |     ["Apple", "ផ្លែប៉ោម"],
  139 |     ["Ball", "បាល់"],
  140 |     ["Cat", "ឆ្មា"],
  141 |     ["Dog", "ឆ្កែ"],
  142 |     ["Egg", "ស៊ុត"],
  143 |   ]) {
  144 |     await page
  145 |       .locator(".pair-columns>div")
  146 |       .first()
  147 |       .getByRole("button", { name: en, exact: true })
  148 |       .click();
  149 |     await page
  150 |       .locator(".pair-columns>div")
  151 |       .last()
  152 |       .getByRole("button", { name: km, exact: true })
  153 |       .click();
  154 |   }
  155 |   await page.getByRole("button", { name: "Continue បន្ត" }).click();
  156 |   for (const w of ["I", "see", "a", "cat"])
  157 |     await page
  158 |       .locator(".word-bank")
  159 |       .getByRole("button", { name: w, exact: true })
  160 |       .click();
  161 |   await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  162 |   await page.getByRole("button", { name: "Continue បន្ត" }).click();
  163 |   await page
  164 |     .getByRole("button", { name: /Practice without a microphone/ })
  165 |     .click();
  166 |   await page.getByRole("button", { name: /I practiced/ }).click();
  167 |   await page.getByRole("button", { name: "Continue បន្ត" }).click();
  168 |   await page.getByRole("button", { name: /Next line/ }).click();
  169 |   await page.locator(".answer-pick").filter({ hasText: "Ball" }).click();
  170 |   await page.getByRole("button", { name: "Check ពិនិត្យ" }).click();
  171 |   await page.getByRole("button", { name: "Continue បន្ត" }).click();
  172 |   await expect(
  173 |     page.getByRole("heading", { name: "Lesson complete!" }),
  174 |   ).toBeVisible();
  175 |   await endSession(page);
  176 |   await page.getByRole("button", { name: /Claim \+10/ }).click();
  177 |   const saved = await page.evaluate(
  178 |     (k) => JSON.parse(localStorage.getItem(k)!),
  179 |     store,
  180 |   );
  181 |   expect(saved.xp).toBe(20);
  182 |   expect(saved.gems).toBe(65);
  183 |   expect(saved.daily.claimed).toBe(true);
  184 |   expect(saved.completed).toEqual(["u1-l1"]);
  185 | });
  186 | test("create account with email and password, sign in, update password and sync progress", async ({
  187 |   page,
  188 | }) => {
  189 |   const email = `family-${Date.now()}@outlook.test`;
  190 |   const original = "FamilyPassword!2468";
  191 |   const replacement = "NewFamilyPassword!9527";
  192 |   await page.goto("/#profile");
  193 |   await page.getByRole("button", { name: "Sign in / Create account" }).click();
  194 |   await page.getByRole("button", { name: /Create an account/ }).click();
  195 |   await expect(
  196 |     page.getByRole("heading", { name: "Who is learning?" }),
  197 |   ).toBeVisible();
  198 |   await page.getByPlaceholder("e.g. Dara").fill("Dara");
  199 |   await page.getByRole("button", { name: "Continue · បន្ត" }).click();
  200 |   await page.locator(".pin-input").fill("4826");
  201 |   await page.getByRole("button", { name: "5 min", exact: true }).click();
  202 |   await page.getByRole("button", { name: "Continue · បន្ត" }).click();
  203 |   await page.getByPlaceholder("parent@example.com").fill(email);
  204 |   await page.getByPlaceholder("At least 8 characters").fill(original);
  205 |   await page.getByPlaceholder("Type the password again").fill(original);
  206 |   await expect(
  207 |     page.getByText(/No verification code or email is required/i),
  208 |   ).toBeVisible();
  209 |   await expect(page.getByPlaceholder("Verification code")).toHaveCount(0);
  210 |   await page
  211 |     .getByRole("button", { name: "Create account · បង្កើតគណនី" })
  212 |     .click();
  213 |   await expect(
  214 |     page.getByRole("heading", { name: /A friendly daily reminder\?/ }),
  215 |   ).toBeVisible();
  216 |   await page.getByRole("button", { name: /Not now/ }).click();
  217 |   await expect(
  218 |     page.getByRole("heading", { name: "Dara", exact: true }),
  219 |   ).toBeVisible();
  220 |   await expect(page.getByText("Progress backed up")).toBeVisible();
  221 |   let server = await page.request.get("/api/progress");
  222 |   expect(server.ok()).toBeTruthy();
  223 |   expect((await server.json()).progress.name).toBe("Dara");
  224 | 
  225 |   await page
  226 |     .locator(".account-actions")
  227 |     .getByRole("button", { name: "Sign out" })
  228 |     .click();
  229 |   await parentPin(page, "4826");
  230 |   await page.getByRole("button", { name: "Sign in / Create account" }).click();
  231 |   await page
  232 |     .getByRole("dialog")
  233 |     .getByRole("button", { name: "Sign in · ចូលប្រើគណនី" })
> 234 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  235 |   await page.getByPlaceholder("parent@example.com").fill(email);
  236 |   await page.getByPlaceholder("Your password").fill("WrongPassword!2468");
  237 |   await page
  238 |     .getByRole("button", { name: /Sign in/ })
  239 |     .last()
  240 |     .click();
  241 |   await expect(page.locator(".auth-flow .form-error")).toContainText(
  242 |     "Email or password is incorrect",
  243 |   );
  244 |   await page.getByPlaceholder("Your password").fill(original);
  245 |   await page
  246 |     .getByRole("button", { name: /Sign in/ })
  247 |     .last()
  248 |     .click();
  249 |   await expect(
  250 |     page.getByRole("heading", { name: "Dara", exact: true }),
  251 |   ).toBeVisible();
  252 | 
  253 |   await page.getByRole("button", { name: "Change password" }).click();
  254 |   await parentPin(page, "4826");
  255 |   await page.getByLabel("Current password").fill("NotTheCurrentPassword!99");
  256 |   await page.getByLabel(/New password/).fill(replacement);
  257 |   await page
  258 |     .getByRole("button", { name: /Change password/ })
  259 |     .last()
  260 |     .click();
  261 |   await expect(page.locator(".modal .form-error")).toContainText(
  262 |     "current password is incorrect",
  263 |   );
  264 |   await page.getByLabel("Current password").fill(original);
  265 |   await page
  266 |     .getByRole("button", { name: /Change password/ })
  267 |     .last()
  268 |     .click();
  269 |   await expect(page.getByText("Your password has been changed.")).toBeVisible();
  270 |   server = await page.request.get("/api/progress");
  271 |   expect(server.ok()).toBeTruthy();
  272 |   expect((await server.json()).progress.email).toBe(email);
  273 |   await page
  274 |     .locator(".account-actions")
  275 |     .getByRole("button", { name: "Sign out" })
  276 |     .click();
  277 |   await parentPin(page, "4826");
  278 |   await page.getByRole("button", { name: "Sign in / Create account" }).click();
  279 |   await page
  280 |     .getByRole("dialog")
  281 |     .getByRole("button", { name: "Sign in · ចូលប្រើគណនី" })
  282 |     .click();
  283 |   await page.getByPlaceholder("parent@example.com").fill(email);
  284 |   await page.getByPlaceholder("Your password").fill(original);
  285 |   await page
  286 |     .getByRole("button", { name: /Sign in/ })
  287 |     .last()
  288 |     .click();
  289 |   await expect(page.locator(".auth-flow .form-error")).toContainText(
  290 |     "Email or password is incorrect",
  291 |   );
  292 |   await page.getByPlaceholder("Your password").fill(replacement);
  293 |   await page
  294 |     .getByRole("button", { name: /Sign in/ })
  295 |     .last()
  296 |     .click();
  297 |   await expect(
  298 |     page.getByRole("heading", { name: "Dara", exact: true }),
  299 |   ).toBeVisible();
  300 | });
  301 | 
```